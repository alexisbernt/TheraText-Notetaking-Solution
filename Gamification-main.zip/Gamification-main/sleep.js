import { useState } from "react";
import sleep_icon from "./sleep_icon.png";

export default function SleepTracker() {
  const [hours, setHours] = useState(8);
  const [minutes, setMinutes] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);

  const handleCheckboxChange = (option) => {
    setSelectedOption(selectedOption === option ? null : option);
  };

  return (
    <div className="flex flex-col items-center p-6 max-w-md mx-auto bg-white shadow-lg rounded-2xl">
      <h1 className="text-lg font-semibold mb-4">How much sleep did you get last night?</h1>
      <img src={sleep_icon} alt="Sleep Icon" className="w-12 h-12 mb-4" />
      
      <div className="flex space-x-4 mb-4">
        <label className="flex flex-col items-center">
          Hours:
          <input
            type="number"
            min="0"
            max="18"
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="border p-2 rounded w-16 text-center"
          />
        </label>
        <label className="flex flex-col items-center">
          Minutes:
          <input
            type="number"
            min="0"
            max="59"
            step="8"
            value={minutes}
            onChange={(e) => setMinutes(e.target.value)}
            className="border p-2 rounded w-16 text-center"
          />
        </label>
      </div>

      <h2 className="text-lg font-semibold mb-4">Is this more or less sleep than usual?</h2>
      <div className="flex flex-col items-center space-y-2">
        {['More', 'Less', 'About the same'].map((option) => (
          <label key={option} className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selectedOption === option}
              onChange={() => handleCheckboxChange(option)}
              className="w-4 h-4"
            />
            <span>{option}</span>
          </label>
        ))}
      </div>
    </div>
  );
}
