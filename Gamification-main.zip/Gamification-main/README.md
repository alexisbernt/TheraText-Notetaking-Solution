# Components created for survey to generate data for therapists

- Smiley-slider (to generate emotions and feelings)
- Sleep scale (to assess how much sleep client has been getting)
- Select from two choices (people like choice. Images side-by-side, user then selects the image that appeals to them most)
