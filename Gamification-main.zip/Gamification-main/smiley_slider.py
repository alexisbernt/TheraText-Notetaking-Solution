import tkinter as tk
import math


def update_smiley(val):
    # Going to update the smiley face based on the slider 
    val = int(val)
    canvas.delete("mouth")

    # Define mouth position
    x1, y1 = 80, 120  # Start of mouth
    x2, y2 = 120, 120  # End of mouth

    # Adjust mouth curvature based on slider value
    curve = (val - 50) / 50 * 20  # Range from -20 (frown) to +20 (smile)
    y_mid = 130 - curve  # Adjust center height dynamically

    if curve >= 100:
        canvas.create_arc(x1, y1 - curve, x2, y2 + curve, start=0, extent=180, style=tk.ARC, width=3, tag="mouth")
    if curve >= 0:
        canvas.create_arc(x1, y1 - curve, x2, y2 + curve, start=180, extent=180, style=tk.ARC, width=3, tag="mouth")


# Create main window
root = tk.Tk()
root.title("Happy Slider")

# Create canvas for smiley face
canvas = tk.Canvas(root, width=200, height=200, bg="white")
canvas.pack()

# Draw face
canvas.create_oval(50, 50, 150, 150, fill="yellow", outline="black", width=3)

# Draw eyes
canvas.create_oval(75, 80, 85, 90, fill="black")
canvas.create_oval(115, 80, 125, 90, fill="black")

# Initial mouth (neutral)
canvas.create_arc(80, 130, 120, 130, start=0, extent=180, style=tk.ARC, width=3, tag="mouth")

# Create slider
slider = tk.Scale(root, from_=0, to=100, orient=tk.HORIZONTAL, command=update_smiley)
slider.set(50)  # Start in the neutral position
slider.pack()

# Run Tkinter event loop
root.mainloop()
