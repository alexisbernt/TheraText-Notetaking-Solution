import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

# Function to ensure only one checkbox is selected
def check_only_one(var):
    if var.get():
        for other in [more_var, less_var, same_var]:
            if other != var:
                other.set(False)

# Create main application window
root = tk.Tk()
root.title("Sleep Tracker")
root.geometry("400x400")
root.resizable(False, False)

# Load sleep icon
sleep_icon = Image.open("sleep_icon.png")  # Replace with actual path if needed
sleep_icon = sleep_icon.resize((100, 100), Image.LANCZOS)
sleep_icon = ImageTk.PhotoImage(sleep_icon)

# Create and place widgets
title_label = tk.Label(root, text="How much sleep did you get last night?", font=("Arial", 12))
title_label.pack(pady=10)

# Center sleep icon
icon_label = tk.Label(root, image=sleep_icon)
icon_label.pack(pady=10)

# Frame for sleep input
sleep_frame = tk.Frame(root)
sleep_frame.pack()

# Hour selection
hour_label = tk.Label(sleep_frame, text="Hours:")
hour_label.grid(row=0, column=0)
hour_var = tk.IntVar(value=8)  # Default to 8 hours
hour_spinbox = ttk.Spinbox(sleep_frame, from_=0, to=18, textvariable=hour_var, width=5)
hour_spinbox.grid(row=0, column=1)

# Minute selection
minute_label = tk.Label(sleep_frame, text="Minutes:")
minute_label.grid(row=0, column=2)
minute_var = tk.IntVar(value=0)  # Default to 0 mins
minute_spinbox = ttk.Spinbox(sleep_frame, from_=0, to=59, textvariable=minute_var, width=5, increment=8)
minute_spinbox.grid(row=0, column=3)

# Additional question
question_label = tk.Label(root, text="Is this more or less sleep than what you usually get?", font=("Arial", 12))
question_label.pack(pady=10)

# Checkboxes
more_var = tk.BooleanVar()
less_var = tk.BooleanVar()
same_var = tk.BooleanVar()

more_check = tk.Checkbutton(root, text="More", variable=more_var, command=lambda: check_only_one(more_var))
less_check = tk.Checkbutton(root, text="Less", variable=less_var, command=lambda: check_only_one(less_var))
same_check = tk.Checkbutton(root, text="About the same", variable=same_var, command=lambda: check_only_one(same_var))

more_check.pack()
less_check.pack()
same_check.pack()

# Run the application
root.mainloop()
