from rest_framework import serializers
from .models import Survey, TheraUser, Alias


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = TheraUser
        fields = ["id", "username", "password", "token"]
        extra_kwargs = {"password": {"write_only": True}, "token": {"write_only": True}}

    def create(self, validated_data):
        valid_tokens = []
        # PRD "/opt/TheraText-Back-end/tokens"
        # Klayton Dev "C:/TheraText/TestingTokens/tokens"
        with open("/opt/TheraText-Back-end/tokens") as file:  # DONT PUSH THIS
            for token in file.readlines():
                valid_tokens.append(token.strip())
            file.close()
        if validated_data['token'] in valid_tokens:
            user = TheraUser.objects.create_user(**validated_data)
            return user


class AliasSerializer(serializers.ModelSerializer):
    class Meta:
        model = Alias
        fields = ["created_at", "name"]
        extra_kwargs = {"created_at": {"read_only": True}, "name": {"required": True}}


class SurveySerializer(serializers.ModelSerializer):
    alias = AliasSerializer(read_only=True)

    class Meta:
        model = Survey
        fields = ["survey_uuid", "created_at", "author", "title", "state", "last_updated", "due_date", "smiley",
                  "sleep", "social", "puffin", "traffic", "pre_session_question", "alias", "patientDuration",
                  "satisfaction", "recommendation", "type"]
        extra_kwargs = {"author": {"read_only": True}}
