from rest_framework import generics
from django.contrib.auth.models import User
from .models import Survey, Alias
from .serializers import UserSerializer, SurveySerializer, AliasSerializer
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
import uuid


class CreateUserView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [AllowAny]


class SurveyView(generics.ListCreateAPIView):
    serializer_class = SurveySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        author = self.request.user
        return Survey.objects.filter(author=author)

    def perform_create(self, serializer):
        survey_uuid = str(uuid.uuid4())
        alias = None
        if "alias" in self.request.data.keys():
            alias = Alias.objects.get(user=self.request.user, name=self.request.data['alias'])
        serializer.save(author=self.request.user, survey_uuid=survey_uuid, title=self.request.data['title'],
                        due_date=self.request.data['due_date'], alias=alias)
        return {"uuid": survey_uuid}


class SurveyByUUID(generics.RetrieveUpdateAPIView):
    serializer_class = SurveySerializer
    permission_classes = [IsAuthenticated]
    lookup_field = 'survey_uuid'

    def get_queryset(self):
        print(self.kwargs)
        survey_uuid = self.kwargs.get('survey_uuid')
        author = self.request.user
        return Survey.objects.filter(survey_uuid=survey_uuid, author=author)

    def update(self, request, *args, **kwargs):
        survey_uuid = self.kwargs.get('survey_uuid')
        author = self.request.user
        instance = Survey.objects.get(survey_uuid=survey_uuid, author=author)
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)


class AliasView(generics.ListCreateAPIView):
    serializer_class = AliasSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        return Alias.objects.filter(user=user)


    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class SurveyByAlias(generics.ListAPIView):
    serializer_class = SurveySerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        alias = Alias.objects.get(name=self.kwargs.get('alias_name'))
        return Survey.objects.filter(author=user, alias=alias)
