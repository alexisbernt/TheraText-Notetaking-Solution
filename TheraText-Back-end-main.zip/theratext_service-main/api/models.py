from django.db import models
from django.contrib.auth.models import User
import uuid


class TheraUser(User):
    token = models.CharField(max_length=100)


class Alias(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="aliases")
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)


class Survey(models.Model):
    # each survey should be able to track its own state 
    state = models.CharField(max_length=100, default="new")
    type = models.CharField(max_length=100)
    last_updated = models.DateTimeField(auto_now=True)
    due_date = models.DateTimeField(null=True, blank=True)

    smiley_default = {'smile_level': 0}
    sleep_default = {'hours': 0, 'minutes': 0, 'comparison': ''}
    social_default = {'hours': 0, 'minutes': 0, 'comparison': ''}
    puffin_default = {'comparison': ''}
    traffic_default = {'light': ''}
    pre_session_question_default = {'input_text': ''}

    patientDuration_default = {'time': ''}
    satisfaction_default = {"duration": "", "rating": "", "recommendation": ""}
    recommendation_default = {'comparison': ''}

    survey_uuid = models.CharField(max_length=100, primary_key=True, unique=True, default=str(uuid.uuid4()))
    created_at = models.DateTimeField(auto_now_add=True)
    title = models.CharField(max_length=100, default="")
    smiley = models.JSONField(default=smiley_default)
    sleep = models.JSONField(default=sleep_default)
    social = models.JSONField(default=social_default)
    puffin = models.JSONField(default=puffin_default)
    traffic = models.JSONField(default=traffic_default)
    pre_session_question = models.JSONField(default=pre_session_question_default)

    patientDuration = models.JSONField(default=patientDuration_default)
    satisfaction = models.JSONField(default=satisfaction_default)
    recommendation = models.JSONField(default=recommendation_default)

    # author = the User 
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name="surveys")
    alias = models.ForeignKey(Alias, on_delete=models.SET_NULL, null=True, blank=True, related_name='surveys')

    def __str__(self):
        return self.survey_uuid
