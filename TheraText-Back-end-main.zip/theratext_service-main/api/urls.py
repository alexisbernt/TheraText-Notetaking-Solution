from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import CreateUserView, SurveyView, SurveyByUUID, AliasView, SurveyByAlias

urlpatterns = [
    path('user/register/', CreateUserView.as_view(), name="register"),
    path('token/', TokenObtainPairView.as_view(), name="get_token"),
    path('token/refresh/', TokenRefreshView.as_view(), name="refresh"),
    path('surveys/', SurveyView.as_view(), name="survey-view"),
    path('surveys/<survey_uuid>/', SurveyByUUID.as_view(), name="survey-uuid"),
    path('aliases/',  AliasView.as_view(), name="alias-view"),
    path('aliases/<alias_name>/',  SurveyByAlias.as_view(), name="alias-name"),
    path('api-auth/', include("rest_framework.urls")),
]