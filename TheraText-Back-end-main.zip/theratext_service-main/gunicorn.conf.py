import multiprocessing
import os

# The socket to bind. A string of the form: 'HOST:PORT', 'unix:PATH'
bind = "0.0.0.0:8000"

# The number of worker processes that will be started (typically 2-4 workers per core)
# A common formula is `(cpu_count * 2) + 1`
workers = (multiprocessing.cpu_count() * 2) + 1

# The type of workers to use, 'sync' is the default and sufficient for most cases
# Other options include 'eventlet', 'gevent' for async applications
worker_class = 'sync'

# Timeout for a worker process (seconds). If a worker does not respond within this time,
# it is killed and a new one spawned
timeout = 30

# The number of seconds to wait for the next request on a Keep-Alive connection
keepalive = 5

# A filename to use for the PID file. Useful for process management
# pidfile = "/var/run/gunicorn.pid"

# Set the access log file path
# accesslog = "/var/log/gunicorn/access.log"

# Set the error log file path
# errorlog = "/var/log/gunicorn/error.log"

# Log level
loglevel = "info"

# Change directory to specified directory before loading apps
# chdir = "/path/to/your/application/directory"

# Load application code before the worker processes are forked.
# Saves RAM and speeds up boot times, but incompatible with the `--reload` development option
preload_app = False
