module "TheraTest_Instance" {
  source = "./instance"

  db_subnet_group_name   = aws_db_subnet_group.TheraText-subnet-group.name
  vpc_security_group_ids = [aws_security_group.sec-group-allow-sql.id]
  instance_name          = "TheraTest"
  rds_password           = "foobarbaz"
  rds_user               = "foo"
}
