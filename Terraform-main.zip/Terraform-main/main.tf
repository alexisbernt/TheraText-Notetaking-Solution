terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  required_version = ">= 1.2.0"
}

provider "aws" {
  region = "us-east-1"
  profile = "default"
}

resource "aws_vpc" "TheraText-vpc" {
  enable_dns_hostnames = true
  cidr_block = "10.0.0.0/16"
  tags = {
    Name = "TheraText-vpc"
  }
}

# __________________Internet Gateway for the VPC________________________________________________________________________
resource "aws_internet_gateway" "TheraText-inet-gw" {
  vpc_id = aws_vpc.TheraText-vpc.id

  tags = {
    Name = "TheraText-inet-gw"
  }
}

# _________________First subnet for the VPC_____________________________________________________________________________
resource "aws_subnet" "TheraText-subnet-1" {
  vpc_id     = aws_vpc.TheraText-vpc.id
  cidr_block = "10.0.1.0/26"
  availability_zone = "us-east-1a"

  tags = {
    Name = "TheraText-subnet-1"
  }
}

# ___________________Two subnet for the VPC_____________________________________________________________________________
resource "aws_subnet" "TheraText-subnet-2" {
  vpc_id     = aws_vpc.TheraText-vpc.id
  cidr_block = "10.0.1.64/26"
  availability_zone = "us-east-1b"

  tags = {
    Name = "TheraText-subnet-2"
  }
}

# _________________Three subnet for the VPC_____________________________________________________________________________
resource "aws_subnet" "TheraText-subnet-3" {
  vpc_id     = aws_vpc.TheraText-vpc.id
  cidr_block = "10.0.1.128/26"
  availability_zone = "us-east-1c"

  tags = {
    Name = "TheraText-subnet-3"
  }
}

# _________________ Subnet Group________________________________________________________________________________________
resource "aws_db_subnet_group" "TheraText-subnet-group" {
  name       = "theratest_subnet"
  subnet_ids = [
    "${aws_subnet.TheraText-subnet-1.id}",
    "${aws_subnet.TheraText-subnet-2.id}",
    "${aws_subnet.TheraText-subnet-3.id}"
  ]
}

# _________________Security group for the VPC to allow SSH______________________________________________________________
resource "aws_security_group" "sec-group-allow-ssh" {
  name        = "sec-group-allow-ssh"
  description = "Allows SSH connections"
  vpc_id      = aws_vpc.TheraText-vpc.id

  ingress {
    cidr_blocks = ["0.0.0.0/0"]
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
  }

  egress {
    cidr_blocks = [aws_subnet.TheraText-subnet-1.cidr_block,
                    aws_subnet.TheraText-subnet-2.cidr_block,
                    aws_subnet.TheraText-subnet-3.cidr_block]
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
  }

  tags = {
    Name = "sec-group-allow-ssh"
  }
}

# _________________Security group for the VPC to allow SQL______________________________________________________________
resource "aws_security_group" "sec-group-allow-sql" {
  name        = "sec-group-allow-sql"
  description = "Allows SQL connections"
  vpc_id      = aws_vpc.TheraText-vpc.id

  ingress {
    cidr_blocks = ["0.0.0.0/0"]
    from_port   = 3306
    to_port     = 3306
    protocol    = "tcp"
  }

  egress {
    cidr_blocks = ["0.0.0.0/0"]
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
  }

  tags = {
    Name = "sec-group-allow-sql"
  }
}

# _________________Route table for the VPC traffic______________________________________________________________________
resource "aws_route_table" "route-table-1" {
  vpc_id = aws_vpc.TheraText-vpc.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.TheraText-inet-gw.id
  }

  tags = {
    Name = "route-table-1"
  }
}

# _________________Associating the subnet and the route table together__________________________________________________
resource "aws_route_table_association" "TheraText-subnet-1-association" {
  route_table_id = aws_route_table.route-table-1.id
  subnet_id      = aws_subnet.TheraText-subnet-1.id
}

resource "aws_route_table_association" "TheraText-subnet-2-association" {
  route_table_id = aws_route_table.route-table-1.id
  subnet_id      = aws_subnet.TheraText-subnet-2.id
}

resource "aws_route_table_association" "TheraText-subnet-3-association" {
  route_table_id = aws_route_table.route-table-1.id
  subnet_id      = aws_subnet.TheraText-subnet-3.id
}
