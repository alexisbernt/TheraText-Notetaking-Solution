resource "aws_db_instance" "rds" {
  allocated_storage    = 20
  db_name              = "${var.instance_name}_rds"
  engine               = "mysql"
  engine_version       = "8.0"
  instance_class       = "db.t3.micro"
  username             = var.rds_user
  password             = var.rds_password
  parameter_group_name = "default.mysql8.0"
  skip_final_snapshot  = true
  publicly_accessible  = true
  vpc_security_group_ids = var.vpc_security_group_ids
  db_subnet_group_name = var.db_subnet_group_name
}

output "rds_address" {
  value = aws_db_instance.rds.address
}

resource "aws_s3_bucket" "s3_bucket" {
  force_destroy = true

  tags = {
    Name        = "${var.instance_name}"
  }
}

output "s3_bucket_name" {
  value = aws_s3_bucket.s3_bucket.bucket
  sensitive = true
}

resource "aws_iam_user" "iam_user" {
  name = "${var.instance_name}"
  path = "/system/"

  tags = {
    tag-key = "tag-value"
  }
}

resource "aws_iam_access_key" "access_key" {
  user    = aws_iam_user.iam_user.name
}

output "access_key_id" {
  value = aws_iam_access_key.access_key.id
  sensitive = true
}

output "access_key_secret" {
  value = aws_iam_access_key.access_key.secret
  sensitive = true
}

resource "aws_iam_policy" "s3_policy" {
  name        = "${var.instance_name}-policy"
  description = "My test policy"
  policy      = data.aws_iam_policy_document.s3_policy_document.json
}

data "aws_iam_policy_document" "s3_policy_document" {
  statement {
    actions   = ["s3:ListAllMyBuckets"]
    resources = ["arn:aws:s3:::*"]
    effect = "Allow"
  }
  statement {
    actions   = ["s3:*"]
    resources = ["${aws_s3_bucket.s3_bucket.arn}*"]
    effect = "Allow"
  }
}


resource "aws_iam_user_policy_attachment" "attachment" {
  user       = aws_iam_user.iam_user.name
  policy_arn = aws_iam_policy.s3_policy.arn
}
