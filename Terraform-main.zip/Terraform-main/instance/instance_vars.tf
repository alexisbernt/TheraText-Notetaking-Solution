variable "instance_name" {
  type = string
  description = "The name of the instance"
}

variable "vpc_security_group_ids" {
  type = list(string)
  description = "List of security group ids"
}

variable "db_subnet_group_name" {
  type = string
  description = "The name of the subnet group"
}

variable "rds_user" {
  type = string
  description = "The user for the RDS database"
}

variable "rds_password" {
  type = string
  description = "The password for the RDS database"
}
