// backend/server.js
const express = require("express");
const fs = require("fs");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

// post to whatever url we put in here 
app.post("/save-survey", (req, res) => {
  const data = req.body;

  fs.writeFile("surveyResponses.json", JSON.stringify(data, null, 2), (err) => {
    if (err) {
      return res.status(500).send("Error writing file");
    }
    res.send("Survey saved!");
  });
});

app.listen(3001, () => {
  console.log("Server running on port 3001");
});
