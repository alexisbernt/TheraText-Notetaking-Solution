import React, { useState, useEffect } from "react";
import SignIn from "./Pages/SignIn";

function App() {
  return (
    <div className="App">
       <SignIn/>
       {/* <StarterScreen/> */}
    </div>
  );
}
