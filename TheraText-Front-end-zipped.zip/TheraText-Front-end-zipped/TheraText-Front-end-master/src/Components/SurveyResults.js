import React, {useState, useEffect} from 'react';
import {useParams, useNavigate} from "react-router-dom";
import api from "../api";
import {PATHS} from "../constants";
import "../CSS/SurveyEntry.css";
import "../index.css";
import logo from "../Assets/logo1.png";
import NavBar from "../Components/NavBar";
import Template from './Template';


const surveyDefaults = {
    "survey_uuid": "",
    "created_at": "",
    "author": -1,
    "smiley": {
        "smile_level": 50
    },
    "sleep": {
        "hours": 0,
        "minutes": 0,
        "comparison": ""
    },
    "social": {
        "hours": 0,
        "minutes": 0,
        "comparison": ""
    },
    "puffin": {
        "comparison": ""
    },
    "traffic": {
        "light": ""
    },
    "pre_session_question": {
        "input_text": ""
    }
}

const SurveyResults = () => {
    const {uuid} = useParams()
    const navigate = useNavigate()
    const [surveyData, setSurveyData] = useState(surveyDefaults)

    useEffect(() => {
        api
            .get(`/api/surveys/${uuid}/`)
            .then((res) => {
                setSurveyData(res.data)
            })
            .catch((error) => {
                console.error(`ERROR: ${error}`)
            });
    }, []);

    return (
        <div>
            <header className="dashboard-header">
                <div className="header-content">
                    <NavBar/>
                </div>
            </header>
            <div>
                    <div
                        style={{
                            position: "fixed",
                            top: 0,
                            left: 0,
                            width: "100vw",
                            height: "100vh",
                            backgroundColor: "rgba(0,0,0,0.5)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            zIndex: 1000,
                        }}
                    >
                        <div
                            style={{
                                background: "white",
                                padding: "2rem",
                                borderRadius: "8px",
                                boxShadow: "0 2px 10px rgba(0,0,0,0.3)",
                                maxWidth: "500px",
                                width: "90%",
                            }}
                        >
                            <Template smile_level={surveyData.smiley.smile_level} sleep_hours={surveyData.sleep.hours} sleep_minutes={surveyData.sleep.minutes}
                                      sleep_compare={surveyData.sleep.comparison} social_hours={surveyData.social.hours}
                                      social_minutes={surveyData.social.minutes}
                                      social_compare={surveyData.social.comparison} social_excitement={surveyData.puffin.comparison}
                                      future_ready={surveyData.traffic.light} discusion_topics={surveyData.pre_session_question.input_text}/>
                            <div style={{marginTop: "1rem", textAlign: "right"}}>
                                <button
                                    onClick={() => navigate("/surveys")}
                                    style={{
                                        padding: "0.5rem 1rem",
                                        backgroundColor: "#3B82F6",
                                        color: "white",
                                        border: "none",
                                        borderRadius: "4px",
                                        cursor: "pointer",
                                    }}
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    );
};

export default SurveyResults;
