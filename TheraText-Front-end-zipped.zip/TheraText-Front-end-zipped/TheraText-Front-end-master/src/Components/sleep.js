import React, {useState, useEffect} from "react";
import sleep_icon from "../Assets/sleep_icon.png";
import logo from "../Assets/logo1.png";

function SleepTracker({surveyData, updateSurvey}) {
    const [sleepData, setSleepData] = useState(surveyData.sleep)

    useEffect(() => {
        updateSurvey("sleep", sleepData)
    }, [sleepData]);

    const updateSleepData = (key, value) => {
        setSleepData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const handleCheckboxChange = (option) => {
        updateSleepData("comparison", option);
    };

    const handleHoursChange = (option) => {
        updateSleepData("hours", option);
    };

    const handleMinutesChange = (option) => {
        updateSleepData("minutes", option);
    };

    return (
        <>
            {/* Sleep Tracker content */}
            <div
                className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl mt-20"
                style={{
                    width: "100%",
                    height: "450px",
                    textAlign: "center",
                }}
            >
                <h2 className="text-lg font-semibold mb-3">
                    How much sleep did you get last night?
                </h2>

                <img src={sleep_icon} alt="Sleep Icon" className="mb-4" style={{width: "70px", height: "70px"}}/>

                <div className="flex space-x-4 mb-6">
                    <label className="flex flex-col items-center">
                        Hours:
                        <input
                            type="number"
                            min="0"
                            max="18"
                            value={sleepData.hours}
                            onChange={(e) => handleHoursChange(e.target.value)}
                            className="border p-2 rounded w-16 text-center"
                        />
                    </label>
                    <label className="flex flex-col items-center">
                        Minutes:
                        <input
                            type="number"
                            min="0"
                            max="59"
                            step="8"
                            value={sleepData.minutes}
                            onChange={(e) => handleMinutesChange(e.target.value)}
                            className="border p-2 rounded w-16 text-center"
                        />
                    </label>
                </div>

                <h2 className="text-lg font-semibold mb-4">
                    Is this more or less sleep than usual?
                </h2>

                <div className="flex flex-col items-center space-y-3 mb-4">
                    {["More", "Less", "About the same"].map((option) => (
                        <label key={option} className="flex items-center space-x-2">
                            <input
                                type="checkbox"
                                checked={sleepData.comparison === option}
                                onChange={() => handleCheckboxChange(option)}
                                className="w-4 h-4"
                            />
                            <span>{option}</span>
                        </label>
                    ))}
                </div>
            </div>
        </>
    );
}

export {SleepTracker};
