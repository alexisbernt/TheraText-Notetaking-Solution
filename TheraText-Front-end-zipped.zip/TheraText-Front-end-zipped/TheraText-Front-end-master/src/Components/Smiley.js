import React, { useState, useEffect } from "react";
import "../CSS/Smiley.css";
import logo from "../Assets/logo1.png";

function Smiley({ surveyData, updateSurvey }) {
    const [smileyData, setSmileyData] = useState(surveyData.smiley);
    const [showPopup, setShowPopup] = useState(true);

    const updateSmileyData = (key, value) => {
        setSmileyData(prevData => ({
            ...prevData,
            [key]: value
        }));
    };

    const handleSliderChange = (e) => {
        const value = parseInt(e.target.value);
        updateSmileyData("smile_level", value);
    };

    const handleSliderRelease = () => {
        updateSurvey("smiley", smileyData);
    };

    const mouthCurve = (smileyData.smile_level - 50) * 0.02;

    useEffect(() => {
        setSmileyData(surveyData.smiley);
    }, [surveyData]);

    return (
        <>
            {/* POP-UP MODAL */}
            {showPopup && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-xl p-8 w-[90%] max-w-md text-center animate-fadeIn">
                        <h2 className="text-2xl font-semibold mb-4">
                            This survey tool is not intended for crisis situations. 
                        </h2>
                        <p className="text-gray-600 mb-6">
                            If you are in crisis contact: '988.' 
                        </p>
                        <h2 className="text-2xl font-semibold mb-4">
                            Client Agknowledgement:
                        </h2>
                        <p className="text-gray-600 mb-6">
                            If I am in crisis or experiencing thoughts of harming myself or others, I will contact
                            emergency services or go to the nearest emergency room immediately.  
                        </p>
                        <button
                            onClick={() => setShowPopup(false)}
                            className="w-full py-3 rounded-xl bg-black text-white font-medium hover:bg-gray-800 transition"
                        >
                            I Agree
                        </button>
                    </div>
                </div>
            )}

            {/* MAIN CONTENT (hidden until popup is accepted) */}
            {!showPopup && (
                <div
                    className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl mt-20"
                    style={{ width: "100%", textAlign: "center" }}
                >
                    <main className="dashboard-main w-full flex flex-col items-center justify-start">
                        <div className="smiley-card flex flex-col items-center justify-center mt-8 max-h-[600px]">
                            <h2 className="greeting mb-4">Adjust My Mood</h2>

                            <div className="smiley-face mb-4">
                                <div className="eye left-eye"></div>
                                <div className="eye right-eye"></div>
                                <svg className="mouth" viewBox="0 0 100 50">
                                    <path
                                        d={`M 20,25 Q 50,${25 + mouthCurve * 25} 80,25`}
                                        fill="none"
                                        stroke="black"
                                        strokeWidth="4"
                                    />
                                </svg>
                            </div>

                            <input
                                type="range"
                                min="0"
                                max="100"
                                value={smileyData.smile_level}
                                onChange={handleSliderChange}
                                onMouseUp={handleSliderRelease}
                                className="slider mb-4"
                            />

                            <div className="mood-labels mb-6 flex justify-between w-full px-4">
                                <span>😞 Frowning</span>
                                <span>😐 Neutral</span>
                                <span>😊 Smiling</span>
                            </div>
                        </div>
                    </main>
                </div>
            )}
        </>
    );
}

export { Smiley };
