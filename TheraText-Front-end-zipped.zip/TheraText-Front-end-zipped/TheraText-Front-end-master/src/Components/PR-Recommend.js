import { useEffect, useState } from "react";
import "../index.css";

export function PatientRecommendation({ surveyData, updateSurvey }) {
    const [satisfactionData, setSatisfactionData] = useState(
        surveyData.satisfaction || {
            score: 50, // 0 | 50 | 100
            recommendation: "Somewhat likely",
        }
    );

    useEffect(() => {
        updateSurvey("satisfaction", satisfactionData);
    }, [satisfactionData]);

    const handleSliderChange = (value) => {
        let recommendation = "Not likely";

        if (value === 100) recommendation = "Very likely";
        else if (value === 50) recommendation = "Somewhat likely";

        setSatisfactionData({
            score: value,
            recommendation,
        });
    };

    const emoji =
        satisfactionData.score === 100
            ? "👍"
            : satisfactionData.score === 50
            ? "😐"
            : "👎";

    return (
        <div
            className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl"
            style={{
                width: "100%",
                height: "450px",
                textAlign: "center",
                paddingTop: "10px",
                boxSizing: "border-box",
            }}
        >
            <h2 className="text-lg font-semibold mb-3">
                Patient Satisfaction Survey
            </h2>

            <h2 className="text-md font-semibold mb-6">
                How satisfied were you with your experience?
            </h2>

            {/* Animated Emoji */}
            <div
                key={satisfactionData.score}
                className="text-6xl mb-6 transition-transform duration-300 ease-out"
                style={{
                    transform: "scale(1.2)",
                }}
            >
                {emoji}
            </div>

            {/* Slider */}
            <input
                type="range"
                min="0"
                max="100"
                step="50"
                value={satisfactionData.score}
                onChange={(e) => handleSliderChange(Number(e.target.value))}
                className="w-full mt-4 mb-3 cursor-pointer"
                style={{
                    height: "12px",
                    borderRadius: "999px",
                    background: "linear-gradient(to right, #ef4444, #facc15, #22c55e)",
                    WebkitAppearance: "none",
                    appearance: "none",
                    transform: "scaleY(1.6)",
                }}
            />
            <br> 
            </br>

            {/* Labels */}
            <div className="flex justify-between w-full text-sm mt-1 text-gray-600">
                <span>👎 Not satisfied</span>
                <span>😐 Neutral</span>
                <span>👍 Very satisfied</span>
            </div>

            {/* Recommendation text */}
            <p className="mt-6 text-sm text-gray-700">
                Post-session:{" "}
                <span className="font-semibold">
                    {satisfactionData.recommendation}
                </span>
            </p>
        </div>
    );
}