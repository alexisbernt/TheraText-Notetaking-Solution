import {useEffect, useState} from "react";
import puffin from "../Assets/puffin.jpg";
import logo from "../Assets/logo1.png";
import "../index.css";

export function Puffin({surveyData, updateSurvey}) {
    const [puffinData, setPuffinData] = useState(surveyData.puffin)

    useEffect(() => {
        updateSurvey("puffin", puffinData)
    }, [puffinData]);

    const updatePuffinData = (key, value) => {
        setPuffinData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const handleCheckboxChange = (option) => {
        updatePuffinData("comparison", option);
    };

    return (

        <div className="flex flex-col items-center p-6 max-w-md mx-auto bg-white shadow-lg rounded-2xl">
            {/* <img src={puffin} alt="Puffin Icon" className="w-12 h-12 mb-4" /> */}
            <h3 className="text-lg font-semibold mb-4">Did you feel more or less excited to engage with others
                socially?</h3>
            <div className="radio-group">
                {['More', 'Less', 'About the same'].map((option) => (
                    <label key={option}>
                        <input
                            type="radio"
                            name="comparison"
                            value={option}
                            checked={puffinData.comparison === option}
                            onChange={() => handleCheckboxChange(option)}
                        />
                        <span>{option}</span>
                    </label>
                ))}
            </div>
        </div>
    );
}