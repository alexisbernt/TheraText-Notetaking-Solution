import React, {useState} from 'react';


function PopupWrapper({children, setPopupVisible}) {

    const hidePopup = () => {
        setPopupVisible(false);
    };

    return (
        <div style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            backdropFilter: "blur(4px)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
        }}>
            <div style={{
                backgroundColor: "white",
                borderRadius: "12px",
                padding: "40px",
                boxShadow: "0 8px 32px rgba(0, 0, 0, 0.15)",
                border: "1px solid #e5e7eb",
                maxWidth: "400px",
                width: "100%",
                position: "relative"
            }}>
                <button
                    onClick={hidePopup}
                    style={{
                        position: "absolute",
                        top: "16px",
                        right: "16px",
                        width: "32px",
                        height: "32px",
                        borderRadius: "50%",
                        border: "none",
                        backgroundColor: "#f3f4f6",
                        color: "#374151",
                        fontSize: "18px",
                        fontWeight: "600",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        transition: "all 0.2s",
                        outline: "none"
                    }}
                    onMouseEnter={(e) => {
                        e.target.style.backgroundColor = "#e5e7eb";
                        e.target.style.color = "#1f2937";
                    }}
                    onMouseLeave={(e) => {
                        e.target.style.backgroundColor = "#f3f4f6";
                        e.target.style.color = "#374151";
                    }}
                    onMouseDown={(e) => {
                        e.target.style.backgroundColor = "#d1d5db";
                    }}
                >
                    ×
                </button>

                <div style={{
                    fontSize: "15px",
                    color: "#374151",
                    lineHeight: "1.5",
                    paddingRight: "8px"
                }}>
                    {children}
                </div>
            </div>
        </div>
    );
};

export default PopupWrapper;