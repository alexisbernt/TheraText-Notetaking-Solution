import {useEffect, useState} from "react";
import social_icon from "../Assets/social_icon.png";
import logo from "../Assets/logo1.png";
import "../index.css";

export function SocialTracker({surveyData, updateSurvey}) {
    const [socialData, setSocialData] = useState(surveyData.social)

    useEffect(() => {
        updateSurvey("social", socialData)
    }, [socialData]);

    const updateSocialData = (key, value) => {
        setSocialData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const handleCheckboxChange = (option) => {
        updateSocialData("comparison", option);
    };

    const handleHoursChange = (option) => {
        updateSocialData("hours", option);
    };

    const handleMinutesChange = (option) => {
        updateSocialData("minutes", option);
    };

    return (
        <>

            {/* SocialTracker content inside the question-box */}
            <div
                className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl"
                style={{
                    width: "100%",
                    height: "450px", // Matches height from SleepTracker
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "flex-start", // Moves content to the top
                    textAlign: "center",
                    paddingTop: "10px", // To add or sub more space from the top
                    boxSizing: "border-box",
                }}
            >
                <h2 className="text-lg font-semibold mb-3">
                    How much did you engage in social (person-to-person) activities this past week?
                </h2>

                <img src={social_icon} alt="Social Icon" className="mb-4" style={{width: "70px", height: "70px"}}/>

                <div className="flex space-x-4 mb-6">
                    <label className="flex flex-col items-center">
                        Hours:
                        <input
                            type="number"
                            min="0"
                            max="18"
                            value={socialData.hours}
                            onChange={(e) => handleHoursChange(e.target.value)}
                            className="border p-2 rounded w-16 text-center"
                        />
                    </label>
                    <label className="flex flex-col items-center">
                        Minutes:
                        <input
                            type="number"
                            min="0"
                            max="59"
                            step="8"
                            value={socialData.minutes}
                            onChange={(e) => handleMinutesChange(e.target.value)}
                            className="border p-2 rounded w-16 text-center"
                        />
                    </label>
                </div>

                <h1 className="text-lg font-semibold mb-4">

                </h1>
                <h2 className="text-lg font-semibold mb-4">
                    Did you feel more or less excited to engage with others socially?
                </h2>

                <div className="flex flex-col items-center space-y-3">
                    {["More", "Less", "About the same"].map((option) => (
                        <label key={option} className="flex items-center space-x-2">
                            <input
                                type="checkbox"
                                checked={socialData.comparison === option}
                                onChange={() => handleCheckboxChange(option)}
                                className="w-4 h-4"
                            />
                            <span>{option}</span>
                        </label>
                    ))}
                </div>
            </div>
        </>
    );
}
