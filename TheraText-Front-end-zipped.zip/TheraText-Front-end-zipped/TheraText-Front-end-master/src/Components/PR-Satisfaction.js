import { useEffect, useState } from "react";
import "../index.css";

export function PatientSatisfaction({ surveyData, updateSurvey }) {
    const [satisfactionData, setSatisfactionData] = useState(
        surveyData.satisfaction || {
            clinician: "",
            rating: "",
            recommendation: ""
        }
    );

    useEffect(() => {
        updateSurvey("satisfaction", satisfactionData);
    }, [satisfactionData]);

    const updateSatisfactionData = (key, value) => {
        setSatisfactionData(prev => ({
            ...prev,
            [key]: value
        }));
    };

    return (
        <div
            className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl"
            style={{
                width: "100%",
                height: "450px",
                textAlign: "center",
                paddingTop: "10px",
                boxSizing: "border-box",
            }}
        >
            <h2 className="text-lg font-semibold mb-3">
                Patient Satisfaction Survey
            </h2>

            {/* Target Icon */}
            <div
                className="mb-6"
                style={{
                    fontSize: "64px",
                    lineHeight: 1,
                }}
                aria-hidden="true"
            >
                🎯
            </div>

            {/* Clinician Name */}
            <h2 className="text-md font-semibold mb-2">
                Who is your clinician?
            </h2>

            <input
                type="text"
                value={satisfactionData.clinician}
                onChange={(e) =>
                    updateSatisfactionData("clinician", e.target.value)
                }
                placeholder="Enter clinician name"
                className="mb-6 px-4 py-2 border rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-400"
            />

            {/* Satisfaction rating */}
            <h2 className="text-md font-semibold mb-2">
                How satisfied are you with your experience?
            </h2>

            <div className="flex space-x-3 mb-6">
                {[1, 2, 3, 4, 5].map(num => {
                    const isSelected = satisfactionData.rating === num;

                    return (
                        <button
                            key={num}
                            onClick={() => updateSatisfactionData("rating", num)}
                            className={`
                                w-12 h-12 rounded-full border-2
                                transition-all duration-200
                                ${isSelected
                                    ? "bg-blue-500 text-white border-blue-600 scale-110 shadow-md"
                                    : "bg-white text-gray-700 border-gray-300 hover:bg-blue-100"}
                            `}
                        >
                            {num}
                        </button>
                    );
                })}
            </div>
        </div>
    );
}