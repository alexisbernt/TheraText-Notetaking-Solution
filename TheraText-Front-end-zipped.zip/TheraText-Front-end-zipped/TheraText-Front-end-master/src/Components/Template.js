import React from 'react';
import {useEffect, useState} from "react";

const Template = (props) => {
    const [smile_amount, setsmile_amount] = useState("___");
    const [social_compare, setsocial_compare] = useState("___");
    const [gad, setgad] = useState("___");
    const [social_excitement, setsocial_excitement] = useState("___");
    const [future, setfuture] = useState("___");
    const [sleep, setsleep] = useState("___");
    useEffect(() => {
        if (props.smile_level > 66) {
            setsmile_amount("few")
        } else if (props.smile_level < 33) {
            setsmile_amount("high")
        } else {
            setsmile_amount("moderate")
        }

        if (props.social_compare === "less") {
            setsocial_compare("harder")
        } else {
            setsocial_compare("easier")
        }

        if (props.social_excitement === "Less") {
            setsocial_excitement("increased")
            setgad("does")
        } else {
            setsocial_excitement("decreased")
            setgad("does not")
        }

        if (props.future_ready === "Red") {
            setfuture("pessamistic")
        } else {
            setfuture("optimistic")
        }

        if (props.sleep_compare === "Less") {
            setsleep("diminished")
        } else if (props.sleep_compare === "More") {
            setsleep("excessive")
        } else {
            setsleep("adequate")
        }

    })
  return (
    <div>
      The client has engaged in {props.social_hours} hours and {props.social_minutes} minutes worth of social activity this past week.
      According to prior questionnaires, the client felt {props.social_compare} excitement when in these activities.
      The client states that they are having a {social_compare} time when in social situations.
      The client is getting {sleep} sleep, typically getting about {props.sleep_hours} hours a night.
      The client is having more {future} thoughts.
      Client exhibited {smile_amount} signs of depression.
      Client anxiety has {social_excitement} in severity and {gad} meet the criteria for the GAD.
      The client disclosed they had [ {props.discusion_topics} ] they wanted to bring up in session.
    </div>
  );
};

export default Template;
