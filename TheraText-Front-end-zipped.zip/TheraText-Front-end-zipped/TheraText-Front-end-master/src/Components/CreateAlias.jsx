import React, {useState} from "react";
import api from "../api";


const CreateAlias = ({setPopupVisible}) => {
    const [aliasData, setAliasData] = useState({
        name: "",
    })

    const updateAliasData = (key, value) => {
        setAliasData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const
        makeNewAlias = () => {
            api
                .post(`/api/aliases/`, aliasData)
                .then((res) => {
                    setPopupVisible(false)
                })
                .catch((error) => {
                    console.error(`ERROR: ${error}`)
                });
        }

    return (
        <div style={{
            backgroundColor: "white",
            borderRadius: "12px",
            padding: "24px",
            boxShadow: "0 4px 16px rgba(0, 0, 0, 0.1)",
            border: "1px solid #e5e7eb",
            maxWidth: "500px",
            margin: "0 auto"
        }}>
            <div style={{
                marginBottom: "20px"
            }}>
                <label style={{
                    display: "block",
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "#374151",
                    marginBottom: "8px"
                }}>
                    Alias Name
                </label>
                <input
                    type="text"
                    onChange={(event) => updateAliasData("name", event.target.value)}
                    style={{
                        width: "100%",
                        padding: "12px 16px",
                        fontSize: "14px",
                        border: "2px solid #d1d5db",
                        borderRadius: "8px",
                        backgroundColor: "#f9fafb",
                        transition: "all 0.2s",
                        outline: "none",
                        boxSizing: "border-box"
                    }}
                    onFocus={(e) => {
                        e.target.style.borderColor = "#7c3aed";
                        e.target.style.backgroundColor = "white";
                        e.target.style.boxShadow = "0 0 0 3px rgba(124, 58, 237, 0.1)";
                    }}
                    onBlur={(e) => {
                        e.target.style.borderColor = "#d1d5db";
                        e.target.style.backgroundColor = "#f9fafb";
                        e.target.style.boxShadow = "none";
                    }}
                    placeholder="Enter alias name..."
                />
            </div>
            <button
                onClick={makeNewAlias}
                style={{
                    width: "100%",
                    padding: "14px 24px",
                    backgroundColor: "#7c3aed",
                    color: "white",
                    border: "none",
                    borderRadius: "8px",
                    fontSize: "15px",
                    fontWeight: "600",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "8px",
                    boxShadow: "0 2px 4px rgba(124, 58, 237, 0.2)"
                }}
                onMouseEnter={(e) => {
                    e.target.style.transform = "translateY(-2px)";
                    e.target.style.boxShadow = "0 6px 20px rgba(124, 58, 237, 0.3)";
                    e.target.style.backgroundColor = "#6d28d9";
                }}
                onMouseLeave={(e) => {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.boxShadow = "0 2px 4px rgba(124, 58, 237, 0.2)";
                    e.target.style.backgroundColor = "#7c3aed";
                }}
                onMouseDown={(e) => {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.backgroundColor = "#5b21b6";
                }}
            >
                <span style={{fontSize: "18px"}}>+</span> Create Alias
            </button>
        </div>
    )
}

export default CreateAlias
