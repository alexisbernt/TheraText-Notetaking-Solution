import { useEffect, useState } from "react";
import "../index.css";

export function PatientDuration({ surveyData, updateSurvey }) {
    const [duration, setDuration] = useState(
        surveyData.patientDuration.level || ""
    );
    const [showPopup, setShowPopup] = useState(true);

    useEffect(() => {
        updateSurvey("patientDuration", {"level": duration});
    }, [duration]);

    return (
        <>
            {/* POP-UP MODAL */}
            {showPopup && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-xl p-8 w-[90%] max-w-md text-center animate-fadeIn">
                        <h2 className="text-2xl font-semibold mb-4">
                            This survey tool is not intended for crisis and emergency situations.
                        </h2>
                        <p className="text-gray-600 mb-6">
                            If this is an emergency or you are in crisis, please contact: <strong>988</strong>.
                        </p>

                        <h2 className="text-2xl font-semibold mb-4">
                            Client Acknowledgement:
                        </h2>
                        <p className="text-gray-600 mb-6">
                            If I am in crisis or experiencing thoughts of harming
                            myself or others, I will contact emergency services or
                            go to the nearest emergency room immediately.
                        </p>

                        <button
                            onClick={() => setShowPopup(false)}
                            className="w-full py-3 rounded-xl bg-black text-white font-medium hover:bg-gray-800 transition"
                        >
                            I Agree
                        </button>
                    </div>
                </div>
            )}

            {/* MAIN CONTENT (hidden until popup accepted) */}
            {!showPopup && (
                <div
                    className="flex flex-col items-center p-6 bg-white shadow-lg rounded-2xl"
                    style={{
                        width: "100%",
                        height: "450px",
                        textAlign: "center",
                        paddingTop: "10px",
                        boxSizing: "border-box",
                    }}
                >
                    <h2 className="text-lg font-semibold mb-3">
                        How long have you been a patient at our practice?
                    </h2>

                    {/* Clock Icon */}
                    <div
                        className="mb-6"
                        style={{
                            fontSize: "64px",
                            lineHeight: 1,
                        }}
                        aria-hidden="true"
                    >
                        ⏱️
                    </div>

                    <br />

                    {/* Radio Options */}
                    <div className="flex flex-col space-y-8 items-start">
                        {[
                            "0–3 months",
                            "4–12 months",
                            "1 year",
                            "1-2 years",
                            "2-3 years",
                            "3+ years",
                        ].map(option => (
                            <label
                                key={option}
                                className="block w-full cursor-pointer"
                            >
                                <div className="flex items-center gap-4">
                                    <input
                                        type="radio"
                                        name="patientDuration"
                                        checked={duration === option}
                                        onChange={() => setDuration(option)}
                                        className="w-4 h-4"
                                    />
                                    <span className="text-sm">{option}</span>
                                </div>
                            </label>
                        ))}
                    </div>
                </div>
            )}
        </>
    );
}