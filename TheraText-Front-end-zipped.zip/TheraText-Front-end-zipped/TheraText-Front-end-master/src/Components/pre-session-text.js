import {useEffect, useState} from "react";
import logo from "../Assets/logo1.png";
import "../index.css";

export function PreSessionQuestion({surveyData, updateSurvey}) {
    const [questionData, setQuestionData] = useState(surveyData.pre_session_question)

    useEffect(() => {
        updateSurvey("pre_session_question", questionData)
    }, [questionData]);

    const updateQuestionData = (key, value) => {
        setQuestionData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const handleTextChange = (option) => {
        updateQuestionData("input_text", option);
    };

    return (
        <div className="flex flex-col items-center p-6 max-w-md mx-auto bg-white shadow-lg rounded-2xl">

            {/* Prompt Section */}
            <div className="mt-4 w-full">
                <p className="text-lg font-semibold">Is there anything in particular you would like to talk about
                    today?</p>
                <textarea
                    className="w-full mt-2 p-2 border rounded-lg"
                    rows="4"
                    placeholder="Input your response here..."
                    value={questionData.input_text}
                    onChange={(e) => handleTextChange(e.target.value)}
                ></textarea>
            </div>

            {/* <span>{selectedOption}</span> */}
        </div>
    );
}
