import {useEffect, useState} from "react";
import logo from "../Assets/logo1.png";
import "../index.css";
import "../CSS/TrafficLight.css";

export function TrafficLight({surveyData, updateSurvey}) {
    const [trafficData, setTrafficData] = useState(surveyData.traffic)

    useEffect(() => {
        updateSurvey("traffic", trafficData)
    }, [trafficData]);

    const updateTrafficData = (key, value) => {
        setTrafficData(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const handleCheckboxChange = (option) => {
        updateTrafficData("light", option);
    };

    return (
        <div className="container">

            <h4 className="title">How ready do you feel for your future?</h4>

            <div className="traffic-light">
                <div
                    className={`light red ${trafficData.light === "Red" ? "active" : ""}`}
                    onClick={() => handleCheckboxChange("Red")}
                ></div>
                <div
                    className={`light yellow ${trafficData.light === "Yellow" ? "active" : ""}`}
                    onClick={() => handleCheckboxChange("Yellow")}
                ></div>
                <div
                    className={`light green ${trafficData.light === "Green" ? "active" : ""}`}
                    onClick={() => handleCheckboxChange("Green")}
                ></div>
            </div>
            <p className="status">{trafficData.light} Light</p>
        </div>
    );
}
