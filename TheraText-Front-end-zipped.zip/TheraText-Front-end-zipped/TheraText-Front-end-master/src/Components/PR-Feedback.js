// Altered for Survey2 – Feedback Box

import { useEffect, useState } from "react";
import "../index.css";

export function PatientFeedback({ surveyData, updateSurvey }) {
    const [questionData, setQuestionData] = useState(
        surveyData.pre_session_question || {
            input_text: "",
        }
    );

    useEffect(() => {
        updateSurvey("pre_session_question", questionData);
    }, [questionData]);

    const handleTextChange = (value) => {
        setQuestionData({
            input_text: value,
        });
    };

    return (
        <div className="flex flex-col items-center p-6 max-w-md mx-auto bg-white shadow-lg rounded-2xl">
            
            {/* Feedback Header */}
            <h2 className="text-lg font-semibold mb-2">
                Additional Feedback
            </h2>

            <p className="text-sm text-gray-600 mb-4 text-center">
                Please share any thoughts, concerns, or feedback you would like us to know.
            </p>

            {/* Feedback Textarea */}
            <textarea
                className="w-full p-3 border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-blue-400"
                rows="5"
                placeholder="Type your feedback here..."
                value={questionData.input_text}
                onChange={(e) => handleTextChange(e.target.value)}
            />
        </div>
    );
}