import {useState} from "react";


const DatePicker = ({updateSurveyData}) => {
    const [selectedDate, setSelectedDate] = useState(null);
    const [isOpen, setIsOpen] = useState(false);
    const [inputValue, setInputValue] = useState('');
    const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

    const handleInputChange = (e) => {
        setInputValue(e.target.value);
    };

    const handleFocus = () => {
        setIsOpen(true);
        document.getElementById('date-input').style.borderColor = "#7c3aed";
        document.getElementById('date-input').style.backgroundColor = "white";
        document.getElementById('date-input').style.boxShadow = "0 0 0 3px rgba(124, 58, 237, 0.1)";
    };

    const handleBlur = () => {
        document.getElementById('date-input').style.borderColor = "#d1d5db";
        document.getElementById('date-input').style.backgroundColor = "#f9fafb";
        document.getElementById('date-input').style.boxShadow = "none";

        if (inputValue) {
            const date = parseDate(inputValue);
            if (date) {
                setSelectedDate(date);
            }
        }
    };

    const handleDateSelect = (date) => {
        updateSurveyData("due_date", date)
        setSelectedDate(date);
        setInputValue(formatDate(date));
        setIsOpen(false);
    };

    const formatDate = (date) => {
        const d = new Date(date);
        const month = d.getMonth() + 1;
        const day = d.getDate();
        const year = d.getFullYear();
        return `${month}/${day}/${year}`;
    };

    const parseDate = (dateString) => {
        const regex = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
        if (!regex.test(dateString)) return null;

        const parts = dateString.split('/');
        const d = new Date(parts[2], parts[0] - 1, parts[1]);
        return d;
    };

    const getDaysInMonth = (year, month) => {
        return new Date(year, month + 1, 0).getDate();
    };

    const getFirstDayOfMonth = (year, month) => {
        return new Date(year, month, 1).getDay();
    };

    const generateCalendarDays = () => {
        const year = currentYear;
        const month = currentMonth;
        const daysInMonth = getDaysInMonth(year, month);
        const firstDay = getFirstDayOfMonth(year, month);

        const days = [];
        // Add empty cells for days before the first day of the month
        for (let i = 0; i < firstDay; i++) {
            days.push(null);
        }

        // Add days of the month
        for (let i = 1; i <= daysInMonth; i++) {
            const date = new Date(year, month, i);
            days.push(date);
        }

        return days;
    };

    const calendarDays = generateCalendarDays();

    const handlePrevMonth = () => {
        setCurrentMonth(currentMonth === 0 ? 11 : currentMonth - 1);
        setCurrentYear(currentMonth === 0 ? currentYear - 1 : currentYear);
    };

    const handleNextMonth = () => {
        setCurrentMonth(currentMonth === 11 ? 0 : currentMonth + 1);
        setCurrentYear(currentMonth === 11 ? currentYear + 1 : currentYear);
    };

    const handleTodayClick = () => {
        const today = new Date();
        handleDateSelect(today);
    };

    return (
        <div style={{position: 'relative'}}>
            <input
                id="date-input"
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onFocus={handleFocus}
                onBlur={handleBlur}
                style={{
                    width: "100%",
                    padding: "12px 16px",
                    fontSize: "14px",
                    border: "2px solid #d1d5db",
                    borderRadius: "8px",
                    backgroundColor: "#f9fafb",
                    transition: "all 0.2s",
                    outline: "none",
                    boxSizing: "border-box"
                }}
                placeholder="Select due date..."
            />

            {isOpen && (
                <div style={{
                    position: 'absolute',
                    top: '100%',
                    left: '0',
                    zIndex: '10',
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
                    width: '100%',
                    maxHeight: '300px',
                    overflowY: 'auto',
                    padding: '10px',
                    border: '1px solid #e5e7eb'
                }}>
                    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px'}}>
                        <button onClick={handlePrevMonth} style={{background: 'none', border: 'none', cursor: 'pointer', fontSize: '16px'}}>&lt;</button>
                        <h3 style={{margin: '0', padding: '0', fontSize: '16px'}}>{new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long' })} {currentYear}</h3>
                        <button onClick={handleNextMonth} style={{background: 'none', border: 'none', cursor: 'pointer', fontSize: '16px'}}>&gt;</button>
                    </div>

                    <div style={{display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '5px'}}>
                        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                            <div key={day} style={{padding: '10px', textAlign: 'center', fontWeight: 'bold', color: '#6b7280'}}>{day}</div>
                        ))}

                        {calendarDays.map((day, index) => {
                            const isToday = day && day.toDateString() === new Date().toDateString();
                            const isSelected = day && selectedDate && day.toDateString() === selectedDate.toDateString();

                            return (
                                <button
                                    key={index}
                                    onClick={() => day && handleDateSelect(day)}
                                    style={{
                                        padding: '10px',
                                        textAlign: 'center',
                                        border: 'none',
                                        backgroundColor: isSelected ? '#7c3aed' ? 'white' : '#f3f4f6' : 'white',
                                        color: isSelected ? 'white' : '#1f2937',
                                        borderRadius: '5px',
                                        cursor: 'pointer',
                                        fontWeight: isToday ? 'bold' : 'normal'
                                    }}
                                >
                                    {day ? day.getDate() : ''}
                                </button>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
};

export default DatePicker