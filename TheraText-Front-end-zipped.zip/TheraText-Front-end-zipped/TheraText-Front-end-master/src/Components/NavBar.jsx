import React, { useState, useEffect } from 'react';
import '../CSS/NavBar.css'
import logo from "../Assets/logo1-transparent.png";
import { FRONTEND_URL } from "../constants"
import Popup from "./Popup"
import api from "../api";
import Survey2 from '../Pages/Survey2';

const NavBar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [generatedLink, setGeneratedLink] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (popupVisible) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.body.style.overflow = 'scroll';
    };
  }, [popupVisible]);

  const handleSurveyLinkClick = async () => {
    api
        .post("/api/surveys/", {survey_num: 18})
        .then((res) => res.data)
        .then(async (data) => {
          setGeneratedLink(`${FRONTEND_URL}/surveys/${data.survey_uuid}`);
          setPopupVisible(true)
          console.log(data)
        }).catch(() => {
        });
  }


  return (
    <nav className={`navbar ${isScrolled ? 'navbar-scrolled' : ''}`}>
      <div className="navbar-container">
        <div className="navbar-logo">
          <a href="/home" className="logo-link">
            <img src={logo} alt="Logo" className="logo"/>
          </a>
        </div>
        <ul className="navbar-menu">
          <li className="navbar-item">
            <a href="/home" className="navbar-link">Home</a>
          </li>
          <li className="navbar-item">
            <a href="/surveys" className="navbar-link">Surveys</a>
          </li>
        </ul>
        <li className={"navbar-item login-logout-button"}>
          <a href="/logout" className="navbar-link">Logout</a>
        </li>
        {popupVisible ? (
            <Popup
            setPopupVisible={setPopupVisible}
            popupText={generatedLink}
            />
        ) : null}
      </div>
    </nav>
  );
};

export default NavBar;