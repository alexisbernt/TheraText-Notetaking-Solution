import React, { useState } from 'react';
import '../CSS/Popup.css'

function Popup({ setPopupVisible, popupText }) {

  const hidePopup = () => {
    setPopupVisible(false);
  };

  return (
    <div>
        <div className="popup-overlay">
          <div className="popup-popup">
            <div className="popup-content">
              <p>{popupText}</p>
              <button className="close-btn" onClick={hidePopup}>×</button>
            </div>
          </div>
        </div>
    </div>
  );
};

export default Popup;