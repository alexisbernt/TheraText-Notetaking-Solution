export const ACCESS_TOKEN = "access"
export const REFRESH_TOKEN = "refresh"
export const PATHS = [
    "/api/smileys/",
    "/api/sleeps/",
    "/api/socials/",
    "/api/puffins/",
    "/api/traffics/",
    "/api/presessionquestions/",
]
export let BACKEND_URL = "https://api.theratext.site"
if (window.location.hostname === "localhost"){
    BACKEND_URL = "http://localhost:8000"
}
export const FRONTEND_URL = "https://dev.theratext.site"
