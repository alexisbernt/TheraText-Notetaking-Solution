import { useState } from "react";
import joy from "./joy.png";
import sadness from "./sadness.png";


function ImageSelectionGame() {
  const [imageIndex, setImageIndex] = useState(0);
  
  const imagePairs = [
    [{sadness}, {joy}]
    // ["https://via.placeholder.com/200/3357FF", "https://via.placeholder.com/200/FF33A1"],
    // ["https://via.placeholder.com/200/A133FF", "https://via.placeholder.com/200/33FFA1"]
  ];

  const handleImageClick = () => {
    if (imageIndex < imagePairs.length - 1) {
      setImageIndex(imageIndex + 1);
    } else {
      alert("Game Over! Thanks for playing.");
    }
  };

  return (
    <div className="image-selection-game" style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", backgroundColor: "#E3F2FD" }}>
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#1E3A5F" }}>Select an Image</h1>
      <div className="image-container" style={{ display: "flex", gap: "20px" }}>
        {imagePairs[imageIndex].map((imgSrc, idx) => (
          <img 
            key={idx} 
            src={imgSrc} 
            alt={`Option ${idx + 1}`} 
            onClick={handleImageClick} 
            style={{ cursor: "pointer", width: "200px", height: "200px", borderRadius: "10px", boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)" }}
          />
        ))}
      </div>
    </div>
  );
}

export default ImageSelectionGame;
