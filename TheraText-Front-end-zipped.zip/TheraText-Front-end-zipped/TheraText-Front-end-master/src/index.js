import React from "react";
import ReactDOM from "react-dom/client";
import {BrowserRouter as Router, Routes, Route, Navigate} from "react-router-dom";
import SignIn from "./Pages/SignIn";
import SignUp from "./Pages/SignUp";
import Survey from "./Pages/Survey"
import ProtectedRoute from "./Components/ProtectedRoute.jsx";
import SurveyResults from "./Components/SurveyResults";
import Home from "./Pages/Dashboard.js";
import './SignIn.css'
import NotepadApp from "./Pages/NotePad.js";
import AppointmentsPage from "./Pages/Appointments.js";
import CommingSoon from "./Pages/CommingSoon.jsx"
import TaylorSwiftApp from "./Pages/Embody.js";
import ListSurveys from "./Pages/ListSurveys"
import Survey2 from "./Pages/Survey2.js";
import SurveyManager from "./Pages/SurveyManager";


const root = ReactDOM.createRoot(document.getElementById("root"));

function Logout() {
    localStorage.clear()
    return <Navigate to='/signin'/>
}

root.render(
    <Router>
        <div className="App">

            {/* Page Routes */}
            <Routes>
                <Route path={"/surveys/:uuid"} element={<SurveyManager/>}/>
                <Route path="/surveys" element={
                    <ProtectedRoute>
                        <ListSurveys/>
                    </ProtectedRoute>
                }
                />
                <Route path="surveys/results/:uuid" element={
                    <ProtectedRoute>
                        <SurveyResults/>
                    </ProtectedRoute>
                }
                />
                <Route path="/home" element={
                    <ProtectedRoute>
                        <Home/>
                    </ProtectedRoute>
                }
                />
                <Route path="/" element={
                    <ProtectedRoute>
                        <Home/>
                    </ProtectedRoute>
                }
                />
                <Route path="/notepad" element={
                    <ProtectedRoute>
                        {/*<NotepadApp />*/}
                        <CommingSoon/>
                    </ProtectedRoute>
                }
                />
                <Route path="/appointments" element={
                    <ProtectedRoute>
                        {/*<AppointmentsPage />*/}
                        <CommingSoon/>
                    </ProtectedRoute>
                }
                />
                <Route path="/guides" element={
                    <ProtectedRoute>
                        <CommingSoon/>
                    </ProtectedRoute>
                }
                />
                <Route path="/signin" element={<SignIn/>}/>
                <Route path="/signup" element={<SignUp/>}/>
                <Route path="/logout" element={<Logout/>}/>
                {/* The "easter egg" of TheraText:  */}
                <Route path="/embody" element={<TaylorSwiftApp/>}/>
            </Routes>
        </div>
    </Router>
);