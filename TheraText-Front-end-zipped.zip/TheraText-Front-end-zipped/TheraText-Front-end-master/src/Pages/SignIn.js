import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import { ACCESS_TOKEN, REFRESH_TOKEN } from "../constants.js";

import logo from "../Assets/logo2.png";
import rocks from "../Assets/rocks.png";
import mountains from "../Assets/mountains.png";
import flowers from "../Assets/flowers.png";
import sun from "../Assets/sun.png";
import oregon from "../Assets/oregon.png";

function SignIn() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [randomImage, setRandomImage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const images = [rocks, mountains, flowers, sun, oregon];
    setRandomImage(images[Math.floor(Math.random() * images.length)]);
  }, []);

  const handleSignIn = async (event) => {
    event.preventDefault();
    try {
      localStorage.removeItem(ACCESS_TOKEN)
      const res = await api.post("/api/token/", { username, password });
      localStorage.setItem(ACCESS_TOKEN, res.data.access);
      localStorage.setItem(REFRESH_TOKEN, res.data.refresh);
      navigate("/home");
    } catch (error) {
      if (error.response && error.response.status === 401) {
        alert("Username and password do not match.");
      } else {
        alert("An error occurred. Please try again.");
      }

      console.error("Login failed:", error.response?.data || error.message);
    }
  };
  

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", background: "linear-gradient(to bottom right, #f0faf9, #d9f1ec)" }}>
      
      {/* Body */}
      <div style={{ flex: 1, display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", padding: "40px", gap: "60px", flexWrap: "wrap" }}>
        
        {/* Login Card */}
        <div style={{
          width: "100%",
          maxWidth: "420px",
          background: "white",
          padding: "40px",
          borderRadius: "16px",
          boxShadow: "0 6px 30px rgba(0,0,0,0.1)",
          position: "relative"
        }}>
          <div style={{ display: "flex", justifyContent: "center" }}>
            <img src={logo} alt="Therapy Logo" style={{ width: "80px", marginBottom: "20px", marginTop: "-60px" }} />
          </div>

          <h2 style={{ textAlign: "center", fontSize: "26px", fontWeight: "600", color: "#333", marginBottom: "8px" }}>
            Welcome Back
          </h2>
          <p style={{ textAlign: "center", color: "#666", marginBottom: "28px" }}>
            Sign in to continue to TheraText Solutions
          </p>

          <form onSubmit={handleSignIn}>
            <div style={{ marginBottom: "20px" }}>
              <label htmlFor="username" style={{ display: "block", fontSize: "14px", color: "#444", marginBottom: "6px" }}>
                Username
              </label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
                style={{
                  width: "100%",
                  padding: "12px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                  outline: "none",
                  transition: "all 0.2s"
                }}
                onFocus={(e) => (e.target.style.border = "1px solid #269581")}
                onBlur={(e) => (e.target.style.border = "1px solid #ccc")}
              />
            </div>

            <div style={{ marginBottom: "30px" }}>
              <label htmlFor="password" style={{ display: "block", fontSize: "14px", color: "#444", marginBottom: "6px" }}>
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                style={{
                  width: "100%",
                  padding: "12px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                  outline: "none",
                  transition: "all 0.2s"
                }}
                onFocus={(e) => (e.target.style.border = "1px solid #269581")}
                onBlur={(e) => (e.target.style.border = "1px solid #ccc")}
              />
            </div>

            <button
              type="submit"
              style={{
                width: "100%",
                padding: "14px",
                borderRadius: "8px",
                background: "#269581",
                color: "white",
                fontWeight: "600",
                border: "none",
                cursor: "pointer",
                transition: "background 0.2s"
              }}
              onMouseOver={(e) => (e.target.style.background = "#1f7a69")}
              onMouseOut={(e) => (e.target.style.background = "#269581")}
            >
              Sign In
            </button>
          </form>

          <p style={{ textAlign: "center", fontSize: "14px", marginTop: "20px", color: "#555" }}>
            Don’t have an account?{" "}
            <span
              onClick={() => navigate("/signup")}
              style={{ color: "#269581", cursor: "pointer", fontWeight: "500" }}
              onMouseOver={(e) => (e.target.style.textDecoration = "underline")}
              onMouseOut={(e) => (e.target.style.textDecoration = "none")}
            >
              Sign up
            </span>
          </p>
        </div>

        {/* Image Section */}
        <div style={{ flex: "1 1 40%", maxWidth: "500px", display: "none", flexShrink: 0 }}>
          {randomImage && (
            <img
              src={randomImage}
              alt="Random Display"
              style={{ width: "100%", borderRadius: "16px", boxShadow: "0 6px 20px rgba(0,0,0,0.1)", objectFit: "cover" }}
            />
          )}
        </div>
      </div>

      {/* Footer */}
      <footer style={{ background: "#269581", color: "white", textAlign: "center", padding: "16px", fontSize: "14px" }}>
        TheraText Solutions · Kearney, NE <br />
        theratext.solutions@gmail.com
      </footer>
    </div>
  );
  
}

export default SignIn;