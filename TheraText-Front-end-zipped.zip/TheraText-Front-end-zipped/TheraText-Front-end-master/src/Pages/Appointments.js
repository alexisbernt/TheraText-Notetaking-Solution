import { Link } from "wouter"; 
import { useState } from 'react';
import { CardHeader, CardContent, CardTitle } from './Dashboard';
import "../CSS/Appointment.css"
import { Button } from "./Dashboard";
import { Card } from "./Dashboard";
import NavBar from "../Components/NavBar";

export default function AppointmentsPage() {
  const [maxAppointments, setMaxAppointments] = useState(5);
  const [appointmentsCount, setAppointmentsCount] = useState(0);
  const [surveysCount, setSurveysCount] = useState(0);

  const increaseAppointments = () => {
    if (appointmentsCount < maxAppointments) {
      setAppointmentsCount(prev => prev + 1);
    }
  };

  const decreaseAppointments = () => {
    if (appointmentsCount > 0) {
      setAppointmentsCount(prev => prev - 1);
    }
  };

  const increaseSurveys = () => setSurveysCount(prev => prev + 1);
  const decreaseSurveys = () => {
    if (surveysCount > 0) setSurveysCount(prev => prev - 1);
  };

  return (
      <div>
        <header className="dashboard-header">
          <div className="header-content">
            <NavBar/>
          </div>
        </header>
        <div className="max-w-4xl mx-auto p-6">
          <Card className="rounded-2xl shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl">Manage Appointments</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="font-medium">Set Total Appointments</label>
                <input
                    type="number"
                    value={maxAppointments}
                    onChange={(e) => setMaxAppointments(Number(e.target.value))}
                    className="w-full rounded-md border border-gray-300 p-2 text-lg focus:ring focus:ring-blue-300"
                    min={0}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                {/* Appointments Counter */}
                <div className="flex flex-col items-center justify-center rounded-xl bg-blue-50 p-6 shadow-md">
                  <h3 className="text-xl font-semibold mb-2">Appointments Booked</h3>
                  <div className="text-5xl font-bold text-blue-600">{appointmentsCount}</div>
                  <div className="flex gap-3 mt-4">
                    <Button onClick={decreaseAppointments} disabled={appointmentsCount === 0}>
                      −
                    </Button>
                    <Button onClick={increaseAppointments} disabled={appointmentsCount >= maxAppointments}>
                      +
                    </Button>
                  </div>
                  <p className="mt-2 text-sm text-gray-600">
                    Max allowed: {maxAppointments}
                  </p>
                </div>

                {/* Surveys Counter */}
                <div className="flex flex-col items-center justify-center rounded-xl bg-green-50 p-6 shadow-md">
                  <h3 className="text-xl font-semibold mb-2">Surveys Administered</h3>
                  <div className="text-5xl font-bold text-green-600">{surveysCount}</div>
                  <div className="flex gap-3 mt-4">
                    <Button onClick={decreaseSurveys} disabled={surveysCount === 0}>
                      −
                    </Button>
                    <Button onClick={increaseSurveys}>
                      +
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
  );
}
