import {useState, useEffect, useCallback} from "react";
import {useParams} from "react-router-dom";
import Survey from "./Survey";
import Survey2 from "./Survey2";
import api from "../api";


const SurveyManager = () => {
    const {uuid} = useParams();
    const [surveyType, setSurveyType] = useState("")

    useEffect(() => {
        api
            .get(`/api/surveys/${uuid}/`)
            .then((res) => {
                setSurveyType(res.data.type)
            })
            .catch((error) => {
                console.error(`ERROR: ${error}`)
            });
    }, []);

    return (
        <>
            {surveyType === "patient" ? <Survey/> : <Survey2/>}
        </>
    )
}

export default SurveyManager