// src/hooks/useSurveys.js
import { useState, useEffect } from "react";
import api from "../api";

export function useSurveys() {
  const [surveys, setSurveys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSurveys = async () => {
      try {
        const res = await api.get("/api/surveys/author/");
        setSurveys(res.data);
      } catch (err) {
        console.error("Failed to fetch surveys:", err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSurveys();
  }, []);

  return { surveys, loading, error };
}
