// # An algoithm idea I had for when a person is having a hard time making a decision 
// # Ask [celebrity] what they would do in this situation

import React, { useState } from 'react';

function TaylorSwiftApp() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');

  // An example "Taylor Swift style" algorithm
  const taylorSwiftResponse = (question) => {
    const responses = [
      `If I were you, I’d shake it off and move forward with grace.`,
      `This feels like a love story, but maybe you're the hero of it.`,
      `I'd tell you: be fearless and follow your heart.`,
      `In my wildest dreams, I'd say... trust yourself.`,
      `Sometimes the best thing to do is begin again.`,
    ];

    // Pick response based on length of input (to mix it up)
    const index = question.length % responses.length;
    return responses[index];
  };

  const handleAsk = () => {
    if (input.trim() === '') return;
    const reply = taylorSwiftResponse(input);
    setResponse(reply);
    setInput('');
  };

  return (
    <div className="sign-in-section">
      <h2>✨ What Would Taylor Swift Do? ✨</h2>
      <div className="sign-in-form">
        <textarea
          rows="4"
          cols="40"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask Taylor something..."
        />
        <br />
        <button className="nav-button" onClick={handleAsk}>
          Ask Taylor
        </button>
      </div>

      {response && (
        <div className="Page">
          <h1>Taylor’s Advice 🎤</h1>
          <div style={{
            border: '1px solid #ccc',
            padding: '15px',
            borderRadius: '8px',
            backgroundColor: '#fdf2f8',
            fontStyle: 'italic'
          }}>
            {response}
          </div>
        </div>
      )}
    </div>
  );
}

export default TaylorSwiftApp;
