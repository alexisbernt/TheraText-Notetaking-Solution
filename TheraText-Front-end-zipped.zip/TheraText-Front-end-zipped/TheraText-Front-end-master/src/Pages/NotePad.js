import React, { useState } from 'react';

function NotepadApp() {
  const [note, setNote] = useState('');
  const [notes, setNotes] = useState([]);

  const handleSave = () => {
    if (note.trim() !== '') {
      setNotes([...notes, note]);
      setNote('');
    }
  };

  return (
    <div className="sign-in-section">
      <h2>Create a Note</h2>
      <div className="sign-in-form">
        <textarea
          rows="6"
          cols="40"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Write your note here..."
        />
        <br />
        <button className="nav-button" onClick={handleSave}>Save Note</button>
      </div>

      <div className="Page">
        <h1>Saved Notes</h1>
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {notes.map((n, index) => (
            <li key={index} style={{ marginBottom: '15px' }}>
              <div style={{
                border: '1px solid #ccc',
                padding: '10px',
                borderRadius: '5px',
                backgroundColor: '#f9f9f9'
              }}>
                {n}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default NotepadApp;
