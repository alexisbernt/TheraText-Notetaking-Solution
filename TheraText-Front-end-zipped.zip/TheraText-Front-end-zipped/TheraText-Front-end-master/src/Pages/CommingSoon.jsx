import "../CSS/CommingSoon.css"
import NavBar from "../Components/NavBar"

export default function CommingSoon() {
    return (
        <div>
            <NavBar />
            <div className="coming-soon-container">

                <h1 className="comming-soon-header">
                    Coming Soon
                </h1>

                <p className="comming-soon-subtitle">
                    Something amazing is on the way!
                </p>
            </div>
        </div>
    )
}