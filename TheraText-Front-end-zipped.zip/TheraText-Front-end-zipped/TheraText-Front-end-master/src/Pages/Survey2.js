import React, {useState, useEffect} from "react";
import {useParams} from "react-router-dom";
import { PatientDuration } from "../Components/PR-Duration";
import { PatientSatisfaction } from "../Components/PR-Satisfaction";
import { PatientRecommendation } from "../Components/PR-Recommend";
import { PatientFeedback } from "../Components/PR-Feedback";
import api from "../api";
import NavBar from "../Components/NavBar";

const surveyDefaults = {
    survey_uuid: "",
    created_at: "",
    author: -1,
    state: "new",

    // smiley: {
    //     smile_level: 50
    // },

    // sleep: {
    //     hours: 0,
    //     minutes: 0,
    //     comparison: ""
    // },

    patientDuration: {"level": ''},

    satisfaction: {
        duration: "",
        rating: "",
        recommendation: ""
    },

    recommendation: {
        comparison: ""
    },

    // traffic: {
    //     light: ""
    // },

    // pre_session_question: {
    //     input_text: ""
    // }
};

function Survey2() {
    const {uuid} = useParams();
    const [surveyData, setSurveyData] = useState(surveyDefaults)
    const [questionIndex, setQuestionIndex] = useState(0);
    const [showModal, setShowModal] = useState(false);
    const [status, setStatus] = useState(null);

    // Loads survey data off the api - once survey is ready, we will put into backend
    useEffect(() => {
        api
            .get(`/api/surveys/${uuid}/`)
            .then((res) => {
                if (res.data["state"] === "new") {
                    res.data["state"] = "in_progress"
                }
                setSurveyData(res.data)
            })
            .catch((error) => {
                console.error(`ERROR: ${error}`)
                setStatus("error");
                setShowModal(true);
            });
    }, []);

    const updateSurvey = (key, value) => {
        setSurveyData(prevData => ({
            ...prevData,
            [key]: value,
            "last_updated": Date.now()
        }))
    }

    const questions = [
        <PatientDuration key="q2" surveyData={surveyData} updateSurvey={updateSurvey} />,
        <PatientSatisfaction key="q3" surveyData={surveyData} updateSurvey={updateSurvey} />,
        <PatientRecommendation key="q4" surveyData={surveyData} updateSurvey={updateSurvey} />,
        <PatientFeedback key="q5" surveyData={surveyData} updateSurvey={updateSurvey} />
    ];


    const nextQuestion = async () => {
        try {
            if (questionIndex === questions.length - 1) {
                surveyData["state"] = "complete"
            }
            const res = await api.put(`/api/surveys/${uuid}/`, surveyData);
            if (res.status === 200) {
                if (questionIndex === questions.length - 1) {
                    setStatus("success");
                    setShowModal(true);
                } else {
                    setQuestionIndex((prev) => prev + 1);
                }
            } else {
                setStatus("error");
                setShowModal(true);
            }
        } catch (err) {
            console.error("Error details:", err.response?.data || err);
            setStatus("error");
            setShowModal(true);
        }
    };

    const ErrorCard = () => (
        <div
            style={{
                backgroundColor: "#fff",
                padding: "30px",
                borderRadius: "12px",
                textAlign: "center",
                boxShadow: "0px 8px 20px rgba(0,0,0,0.2)",
                width: "400px",
            }}
        >
            <h2 style={{color: "red", marginBottom: "20px"}}>Something went wrong</h2>
            <p style={{marginBottom: "20px", color: "#333"}}>
                An error occurred while processing your request.
                Please try again or return to the home page.
            </p>
            <button
                onClick={() => (window.location.href = "/home")}
                style={{
                    padding: "10px 20px",
                    border: "none",
                    borderRadius: "8px",
                    backgroundColor: "#1E90FF",
                    color: "#fff",
                    cursor: "pointer",
                    fontSize: "16px",
                }}
            >
                Go Home
            </button>
        </div>
    );

    const SuccessCard = () => (
        <div
            style={{
                backgroundColor: "#fff",
                padding: "30px",
                borderRadius: "12px",
                textAlign: "center",
                boxShadow: "0px 8px 20px rgba(0,0,0,0.2)",
                width: "400px",
            }}
        >
            <h2 style={{color: "green", marginBottom: "20px"}}>
                Survey Submitted Successfully!
            </h2>
            <button
                onClick={() => (window.location.href = "/home")}
                style={{
                    padding: "10px 20px",
                    border: "none",
                    borderRadius: "8px",
                    backgroundColor: "#4f46e5",
                    color: "#fff",
                    cursor: "pointer",
                    fontSize: "16px",
                }}
            >
                Return
            </button>
        </div>
    );

    return (
        <div>
            <header className="dashboard-header">
                <div className="header-content">
                    <NavBar/>
                </div>
            </header>

            <div
                className="starter-screen"
                style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    minHeight: "100vh",
                    backgroundColor: "#E3F2FD",
                    paddingTop: "3rem",
                    paddingBottom: "3rem",
                }}
            >
                <h1 className="text-2xl font-bold mb-6" style={{color: "#1E3A5F"}}>
                    Starter Survey
                </h1>

                <div
                    className="question-box"
                    style={{
                        backgroundColor: "#ffffff",
                        padding: "20px",
                        borderRadius: "10px",
                        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                        textAlign: "center",
                        width: "500px",
                        height: "500px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                    }}
                >
                    <div style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center"
                    }}>
                        {questions[questionIndex]}
                    </div>
                </div>
                <button
                    onClick={nextQuestion}
                    className="mt-6 px-6 py-3 bg-blue-500 text-white rounded-lg shadow-lg hover:scale-105 transition-transform"
                    style={{backgroundColor: "#1E90FF"}}
                >
                    Next
                </button>
            </div>

            {/* MODAL */}
            {showModal && (
                <div
                    style={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100vw",
                        height: "100vh",
                        backgroundColor: "rgba(0,0,0,0.5)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 1000,
                    }}
                >
                    {status === "success" ? <SuccessCard/> : <ErrorCard/>}
                </div>
            )}
        </div>
    );
}

export default Survey2;