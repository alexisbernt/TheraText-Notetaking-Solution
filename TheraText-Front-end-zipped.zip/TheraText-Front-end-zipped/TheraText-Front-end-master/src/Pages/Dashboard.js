import "../CSS/Button.css";
import "../CSS/Card.css";
import "../CSS/Dashboard.css";

import React, { useState, useEffect } from "react";
import NavBar from "../Components/NavBar";
import api from "../api";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

/* -----------------------------------------
   REUSABLE CARD + BUTTON COMPONENTS
------------------------------------------ */
export function Card({ children, className = "", ...props }) {
  return (
    <div className={`card modern-card ${className}`} {...props}>
      {children}
    </div>
  );
}

export function CardHeader({ children }) {
  return <div className="card-header modern-card-header">{children}</div>;
}

export function CardTitle({ children, className = "" }) {
  return <h3 className={`card-title modern-card-title ${className}`}>{children}</h3>;
}

export function CardContent({ children, className = "" }) {
  return <div className={`card-content modern-card-content ${className}`}>{children}</div>;
}

export function CardFooter({ children, className = "" }) {
  return <div className={`card-footer modern-card-footer ${className}`}>{children}</div>;
}

export function Button({ children, className = "", variant = "default", ...props }) {
  const baseClass = "btn";
  const variantClass = variant === "link" ? "btn-link" : "btn-default";
  return (
    <button className={`${baseClass} ${variantClass} ${className}`} {...props}>
      {children}
    </button>
  );
}

/* ---------------------------------------------------------
   DASHBOARD (MAIN COMPONENT)
---------------------------------------------------------- */
export default function Dashboard() {
  // Status overview counts
  const [completedCount, setCompletedCount] = useState(0);
  const [newCount, setNewCount] = useState(0);
  const [inProgressCount, setInProgressCount] = useState(0);
  const [loadingStats, setLoadingStats] = useState(true);

  // Activity chart
  const [activityData, setActivityData] = useState([]);

  // Surveys
  const [surveys, setSurveys] = useState([]);

  /* -------------------------
     UPDATE STATS (PUT request)
  -------------------------- */
  async function updateStats(payload) {
    try {
      await api.put("/api/dashboard-stats/", payload);
      fetchStats();
    } catch (e) {
      console.error("Failed to update stats", e);
    }
  }

  // /* -------------------------
  //    FETCH STATS (GET request)
  // -------------------------- */
  // async function fetchStats() {
  //   try {
  //     const res = await api.get("/api/dashboard-stats/");

  //     setInReviewCount(res.data.in_review_count ?? 0);
  //     setDueCount(res.data.due_count ?? 0);
  //     setOverdueCount(res.data.overdue_count ?? 0);

  //     const activity = res.data.activity_log;
  //     setActivityData(Array.isArray(activity) ? activity : []);
  //   } catch (err) {
  //     console.error("Failed to load stats:", err);
  //     setActivityData([]);
  //   } finally {
  //     setLoadingStats(false);
  //   }
  // }

  /* -------------------------
      FETCH STATS (GET request)
    -------------------------- */
    async function fetchStats() {
      try {
        const res = await api.get("/api/surveys/");
        const stats = Array.isArray(res.data) ? res.data : [];

        // Count survey statuses
        const completed = stats.filter(
          (s) => s.state === "complete"
        ).length;

        const newSurveys = stats.filter(
          (s) => s.state === "new"
        ).length;

        const inProgress = stats.filter(
          (s) => s.state === "in_progress"
        ).length;

        setCompletedCount(completed);
        setNewCount(newSurveys);
        setInProgressCount(inProgress);

        // Extract activity logs (optional)
        const activity = stats
          .filter((s) => s.activity_log)
          .map((s) => ({
            text: s.activity_log,
            date: s.last_updated,
          }));

        setActivityData(activity);
      } catch (err) {
        console.error("Failed to load stats:", err);
        setCompletedCount(0);
        setNewCount(0);
        setInProgressCount(0);
        setActivityData([]);
      } finally {
        setLoadingStats(false);
      }
    }


  /* -------------------------
     LOAD SURVEYS
  -------------------------- */
  const loadSurveys = () => {
    api
      .get("/api/surveys/")
      .then((res) => setSurveys([...res.data]))
      .catch((err) => console.error("ERROR loading surveys:", err));
  };

  useEffect(() => {
    api.get("/api/aliases/").then((res) => {
      console.log(res.data)
    }).catch((error) => {
      console.error(error)
    })
    const data = {
      name: "test1"
    }

    // api.post("/api/aliases/", data).then((res) => {
    //   console.log(res)
    // }).catch((error) => {
    //   console.error(error)
    // })

    fetchStats();
    loadSurveys();
  }, []);

  if (loadingStats) {
    return (
      <div className="dashboard-container">
        <p>Loading dashboard stats...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Header */}
      <header className="dashboard-header">
        <div className="header-content">
          <NavBar />
        </div>
      </header>

      {/* Centered welcome */}
      <h1 className="greeting" style={{ textAlign: "center", marginTop: "2rem" }}>
        Welcome! You are on the Dashboard Page 🚀
      </h1>

      {/* Survey Card */}
      <section style={{ marginTop: "2rem", display: "flex", justifyContent: "center" }}>
        <Card className="editable-card" style={{ maxWidth: "500px", width: "100%" }}>
          <CardContent className="card-inner">
            <div className="card-info">
              <CardTitle>Leave your feedback 📰</CardTitle>
              <p>Please fill out this survey once you have gone through the demo process</p>
              <a
                href="https://docs.google.com/forms/d/e/1FAIpQLScuFj0Nr2pIs5GeQYspm_Tx2C473UctrpFwFfD2ikGKFVtNAQ/viewform?usp=header"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: "inline-block",
                  marginTop: "0.75rem",
                  color: "#2563eb",
                  fontWeight: "600",
                  textDecoration: "none",
                }}
              >
                Visit Anonymous Review Survey →
              </a>
            </div>
          </CardContent>
        </Card>
      </section>
      {/* Status Overview Cards */}
      <section className="status-overview" style={{ marginTop: "2rem" }}>
        <h2>Status overview</h2>
        <p className="subtitle">Current and upcoming</p>
        <div className="status-grid">
          <Card className="editable-card">
            <CardContent className="card-inner">
              <div className="card-info">
                <CardTitle>{completedCount} Completed</CardTitle>
                <p>at the moment</p>
              </div>
            </CardContent>
          </Card>

          <Card className="editable-card">
            <CardContent className="card-inner">
              <div className="card-info">
                <CardTitle>{newCount} new</CardTitle>
                <p>In the next 7 days</p>
              </div>
            </CardContent>
          </Card>

          <Card className="editable-card">
            <CardContent className="card-inner">
              <div className="card-info">
                <CardTitle>{inProgressCount} In Progress</CardTitle>
                <p>at the moment</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Recent Activity Chart */}
      {activityData.length > 0 && (
        <section className="recent-activity" style={{ marginTop: "2rem" }}>
          <div className="activity-header">
            <h2>Recent activity</h2>
          </div>
          <div className="activity-graph">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={activityData} margin={{ top: 20, right: 30, left: 0, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="logins" stroke="#4f46e5" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      {/* Active Surveys Summary */}
      <section style={{ marginTop: "2rem" }}>
        <div className="status-grid">
          <Card>
            <CardContent style={{ textAlign: "center" }}>
              <CardTitle>{surveys.length} Total Surveys</CardTitle>
              <p>Total surveys currently created</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Recent Surveys List */}
      <section style={{ marginTop: "2rem", display: "flex", justifyContent: "center" }}>
        <div className="w-[90%] max-w-3xl bg-white rounded-xl shadow p-6">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Recent Surveys</h3>

          {surveys.length === 0 ? (
            <p className="text-gray-500">No surveys found</p>
          ) : (
            <ul className="space-y-3">
              {surveys.map((s, i) => (
                <li
                  key={i}
                  className="p-4 bg-gray-50 rounded-lg border border-gray-200 flex justify-between items-center"
                >
                  <div>
                    <div className="font-medium text-gray-800">{s.title}</div>
                    <div className="text-sm text-gray-500">
                      Created: {new Date(s.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bottom-footer" style={{ marginTop: "2rem" }}>
        <div className="bottom-footer-content">
          <p>
            📧 Contact:{" "}
            <a href="mailto:theratext.solutions@gmail.com">theratext.solutions@gmail.com</a>
          </p>
          <p>📞 Phone: (720)-470-8062</p>

          <nav className="bottom-footer-links">
            <a href="https://github.com/" target="_blank" rel="noopener noreferrer">
              GitHub
            </a>
            <a href="/">Webpage</a>
            <a href="/about">About</a>
            <a href="/signin">Login</a>
          </nav>
        </div>
      </footer>
    </div>
  );
}

{/* ----------------- THREE .JS STUFF ----------------- */}
  // useEffect(() => {
  //   // === Three.js background setup ===
  //   const scene = new THREE.Scene();
  //   const camera = new THREE.PerspectiveCamera(
  //     75,
  //     window.innerWidth / window.innerHeight,
  //     0.1,
  //     1000
  //   );
  //   camera.position.z = 5;

  //   const renderer = new THREE.WebGLRenderer({
  //     canvas: document.getElementById("threejs-bg"),
  //     alpha: true,
  //   });
  //   renderer.setSize(window.innerWidth, window.innerHeight);

  //   // Particles for Three.js
  //   const particles = new THREE.BufferGeometry();
  //   const count = 500;
  //   const positions = new Float32Array(count * 3);
  //   for (let i = 0; i < count * 3; i++) {
  //     positions[i] = (Math.random() - 0.5) * 20;
  //   }
  //   particles.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  //   const material = new THREE.PointsMaterial({
  //     color: 0x38bdf8,
  //     size: 0.12,
  //     sizeAttenuation: true,
  //   });
  //   const points = new THREE.Points(particles, material);
  //   scene.add(points);

  //   // === Text ===
  //   let textMesh;
  //   const loader = new FontLoader();
  //   loader.load(
  //     "https://threejs.org/examples/fonts/helvetiker_regular.typeface.json",
  //     (font) => {
  //       const textGeometry = new TextGeometry("Welcome to TheraText", {
  //         font: font,
  //         size: 0.05,       // smaller size smaller you go
  //         height: 0.01,     // flatter this way..., no chunky extrusion
  //         curveSegments: 12,
  //       });
  //       textGeometry.center();

  //       const textMaterial = new THREE.MeshBasicMaterial({
  //         color: 0x0284c7,
  //         transparent: true,
  //         opacity: 0, // start invisible
  //       });

  //       textMesh = new THREE.Mesh(textGeometry, textMaterial);
  //       textMesh.position.set(0, 0, -1); // slight offset towards camera
  //       scene.add(textMesh);

  //       // Fade in effect
  //       let opacity = 0;
  //       const fadeIn = () => {
  //         if (opacity < 1) {
  //           opacity += 0.01;
  //           textMesh.material.opacity = opacity;
  //           requestAnimationFrame(fadeIn);
  //         }
  //       };
  //       fadeIn();
  //     }
  //   );

  //   // Animate
  //   const animate = () => {
  //     requestAnimationFrame(animate);
  //     points.rotation.y += 0.0015;
  //     renderer.render(scene, camera);
  //   };
  //   animate();

  //   // Handle resize
  //   const handleResize = () => {
  //     camera.aspect = window.innerWidth / window.innerHeight;
  //     camera.updateProjectionMatrix();
  //     renderer.setSize(window.innerWidth, window.innerHeight);
  //   };
  //   window.addEventListener("resize", handleResize);

  //   // Fade out on scroll
  //   const handleScroll = () => {
  //     const welcomeText = document.querySelector(".welcome-text");
  //     if (!welcomeText) return;

  //     if (window.scrollY > 50) {
  //       welcomeText.classList.add("fade-out");
  //     } else {
  //       welcomeText.classList.remove("fade-out");
  //     }
  //   };
  //   window.addEventListener("scroll", handleScroll);

  //   return () => {
  //     window.removeEventListener("resize", handleResize);
  //     window.removeEventListener("scroll", handleScroll);
  //     renderer.dispose();
  //   };
  // }, []);