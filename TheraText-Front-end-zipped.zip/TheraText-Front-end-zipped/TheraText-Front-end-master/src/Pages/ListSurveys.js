import React, {useState, useEffect, useCallback} from "react";
import {useNavigate} from 'react-router-dom';
import api from "../api";
import NavBar from "../Components/NavBar";
import PopupWrapper from "../Components/PopupWrapper"
import CreateSurvey from "../Components/CreateSurvey"
import CreateAlias from "../Components/CreateAlias";

function ListSurveys() {
    const navigate = useNavigate()
    const [showSurveyCreation, setShowSurveyCreation] = useState(false)
    const [showAliasCreation, setShowAliasCreation] = useState(false)
    const [copiedMessage, setCopiedMessage] = useState('')
    const [surveys, setSurveys] = useState([])
    const [aliases, setAliases] = useState([])
    const [filters, setFilters] = useState({alias: ""})

    const filteredSurveys = () => {
        let filtered = surveys
        if (filters.alias !== "") {
            filtered = filtered.filter((survey) => survey.alias?.name === filters.alias)
        }
        return filtered
    }

    const updateFilter = (key, value) => {
        setFilters(prevData => ({
            ...prevData,
            [key]: value
        }))
    }

    const loadSurveys = () => {
        api
            .get("/api/surveys/")
            .then((res) => {
                setSurveys(res.data)
            })
            .catch((error) => {
                console.error(`ERROR: ${error}`)
            });
    }

    const loadAliases = useCallback(() => {
        api
            .get(`/api/aliases/`)
            .then((res) => {
                setAliases(res.data)
            })
            .catch((error) => {
                console.error(`ERROR: ${error}`)
            });
    }, [setAliases])

    async function copySurveyLinkToClipboard(surveyUuid) {
        try {
            await navigator.clipboard.writeText(`${window.location.href}/${surveyUuid}`);
            setCopiedMessage("successfully Copied!");
            setTimeout(() => {
                setCopiedMessage("");
            }, 2000);
        } catch (err) {
            console.error('Failed to copy text: ', err);
            setCopiedMessage("Failed To Copied!");
        }
    }


    useEffect(() => {
        loadSurveys()
        loadAliases()
    }, [showSurveyCreation, loadAliases]);

    return (<div>
        <header className="dashboard-header">
            <div className="header-content">
                <NavBar/>
            </div>
        </header>
        {showSurveyCreation && (<PopupWrapper setPopupVisible={setShowSurveyCreation}>
            <CreateSurvey setPopupVisible={setShowSurveyCreation}/>
        </PopupWrapper>)}
        {showAliasCreation && (<PopupWrapper setPopupVisible={setShowAliasCreation}>
            <CreateAlias setPopupVisible={setShowAliasCreation}/>
        </PopupWrapper>)}
        {copiedMessage.trim() !== '' && (<div
            style={{
                position: "fixed",
                top: "20px",
                left: "50%",
                transform: "translateX(-50%)",
                zIndex: 1000,
                backgroundColor: "#7c3aed",
                color: "white",
                padding: "14px 28px",
                borderRadius: "8px",
                fontSize: "15px",
                fontWeight: "600",
                boxShadow: "0 6px 20px rgba(124, 58, 237, 0.3)",
                animation: "fadeInOut 2s ease-in-out",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                border: "none"
            }}
        >
            <span>✓</span> {copiedMessage}
        </div>)}
        <div style={{display: "flex", gap: "12px", marginTop: "25px"}}>
            <button
                style={{
                    marginTop: "25px",
                    padding: "14px 28px",
                    backgroundColor: "#7c3aed",
                    color: "white",
                    border: "none",
                    borderRadius: "8px",
                    fontSize: "15px",
                    fontWeight: "600",
                    cursor: "pointer",
                    transition: "transform 0.2s, box-shadow 0.2s",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px"
                }}
                onMouseEnter={(e) => {
                    e.target.style.transform = "translateY(-2px)";
                    e.target.style.boxShadow = "0 6px 20px rgba(124, 58, 237, 0.3)";
                }}
                onMouseLeave={(e) => {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.boxShadow = "none";
                }}
                onClick={() => setShowSurveyCreation(true)}
            >
                <span>+</span> Create New Survey
            </button>
            <button
                style={{
                    marginTop: "25px",
                    padding: "14px 28px",
                    backgroundColor: "#7c3aed",
                    color: "white",
                    border: "none",
                    borderRadius: "8px",
                    fontSize: "15px",
                    fontWeight: "600",
                    cursor: "pointer",
                    transition: "transform 0.2s, box-shadow 0.2s",
                    display: "flex",
                    alignItems: "center",
                    gap: "8px"
                }}
                onMouseEnter={(e) => {
                    e.target.style.transform = "translateY(-2px)";
                    e.target.style.boxShadow = "0 6px 20px rgba(124, 58, 237, 0.3)";
                }}
                onMouseLeave={(e) => {
                    e.target.style.transform = "translateY(0)";
                    e.target.style.boxShadow = "none";
                }}
                onClick={() => setShowAliasCreation(true)}
            >
                <span>+</span> Create New Alias
            </button>
        </div>

        {/* Filter Dropdown */}
        <div style={{marginTop: "25px", display: "flex", alignItems: "center", gap: "15px"}}>
            <label style={{fontSize: "14px", fontWeight: "500", color: "#374151"}}>
                Filter by Alias:
            </label>
            <select
                value={filters.alias}
                onChange={(e) => updateFilter("alias", e.target.value)}
                style={{
                    padding: "12px 24px 12px 16px",
                    backgroundColor: "white",
                    border: "1px solid #cbd5e1",
                    borderRadius: "8px",
                    fontSize: "14px",
                    color: "#1f2937",
                    cursor: "pointer",
                    outline: "none",
                    minWidth: "200px",
                    transition: "border-color 0.2s, box-shadow 0.2s"
                }}
                onFocus={(e) => {
                    e.target.style.borderColor = "#7c3aed";
                    e.target.style.boxShadow = "0 0 0 3px rgba(124, 58, 237, 0.1)";
                }}
                onBlur={(e) => {
                    e.target.style.borderColor = "#cbd5e1";
                    e.target.style.boxShadow = "none";
                }}
            >
                <option value="">All Aliases</option>
                {aliases.map((alias) => (
                    <option key={alias?.name} value={alias?.name}>
                        {alias?.name}
                    </option>
                ))}
            </select>
        </div>

        <ul style={{listStyle: "none", padding: 0, marginTop: "30px"}}>
            {filteredSurveys().map((item, index) => (<li
                key={`survey-${index}`}
                style={{
                    backgroundColor: "white",
                    borderRadius: "10px",
                    padding: "20px",
                    marginBottom: "15px",
                    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.08)",
                    borderLeft: "4px solid #7c3aed"
                }}
            >
                <div style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center"
                }}>
                    <div>
                        <div style={{
                            fontSize: "14px", color: "#6b7280", marginBottom: "4px"
                        }}>
                            📅 {item.title}
                        </div>
                        <div style={{
                            fontSize: "11px",
                            color: "#000000",
                            marginTop: "4px",
                            backgroundColor: "#d1ebfd",
                            padding: "2px 8px",
                            borderRadius: "12px",
                            display: "inline-block"
                        }}>
                            Status: {item.state}
                        </div>
                            <div style={{
                                fontSize: "11px",
                                color: "#000000",
                                marginTop: "4px",
                                backgroundColor: "#f3e8ff",
                                padding: "2px 8px",
                                borderRadius: "12px",
                                display: "inline-block"
                            }}>
                                Alias: {item.alias?.name === undefined ? "None" : item.alias?.name}
                            </div>
                            <div style={{
                                fontSize: "11px",
                                color: "#000000",
                                marginTop: "4px",
                                backgroundColor: "#e8fff1",
                                padding: "2px 8px",
                                borderRadius: "12px",
                                display: "inline-block"
                            }}>
                                Type: {item.type}
                            </div>
                    </div>
                    <div style={{display: "flex", gap: "10px"}}>
                        <button
                            style={{
                                padding: "10px 20px",
                                backgroundColor: "#f8fafc",
                                border: "1px solid #cbd5e1",
                                borderRadius: "6px",
                                color: "#475569",
                                fontSize: "13px",
                                fontWeight: "500",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                gap: "6px",
                                transition: "all 0.2s"
                            }}
                            onMouseEnter={(e) => e.target.style.backgroundColor = "#e2e8f0"}
                            onMouseLeave={(e) => e.target.style.backgroundColor = "#f8fafc"}
                            onClick={() => copySurveyLinkToClipboard(item.survey_uuid)}
                        >
                            <span>📋</span> Copy Link
                        </button>
                        <button
                            style={{
                                padding: "10px 20px",
                                backgroundColor: "#f8fafc",
                                border: "1px solid #cbd5e1",
                                borderRadius: "6px",
                                color: "#475569",
                                fontSize: "13px",
                                fontWeight: "500",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                gap: "6px",
                                transition: "all 0.2s"
                            }}
                            onMouseEnter={(e) => e.target.style.backgroundColor = "#e2e8f0"}
                            onMouseLeave={(e) => e.target.style.backgroundColor = "#f8fafc"}
                            onClick={() => navigate(`/surveys/${item.survey_uuid}`)}
                        >
                            <span>✏️</span> Edit
                        </button>
                        <button
                            style={{
                                padding: "10px 20px",
                                backgroundColor: "#0f766e",
                                color: "white",
                                border: "none",
                                borderRadius: "6px",
                                fontSize: "13px",
                                fontWeight: "500",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                gap: "6px",
                                transition: "background-color 0.2s"
                            }}
                            onMouseEnter={(e) => e.target.style.backgroundColor = "#115e59"}
                            onMouseLeave={(e) => e.target.style.backgroundColor = "#0f766e"}
                            onClick={() => navigate(`/surveys/results/${item.survey_uuid}`)}
                        >
                            <span>📊</span> Summary
                        </button>
                    </div>
                </div>
            </li>))}
        </ul>

        <style>
            {`
@keyframes fadeInOut {
    0% {
        opacity: 0;
        transform: translateX(-50%) translateY(-20px);
    }
    15% {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    85% {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    100% {
        opacity: 0;
        transform: translateX(-50%) translateY(-20px);
    }
}
`}
        </style>
    </div>)
}

export default ListSurveys;
