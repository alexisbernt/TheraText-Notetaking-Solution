
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import logo from "./logo2.png";
import rocks from "./rocks.png";
import mountains from "./mountains.png";
import flowers from "./flowers.png";
import sun from "./sun.png";
import oregon from "./oregon.png"

function SignIn() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("")
    const [randomImage, setRandomImage] = useState(null);
    const navigate = useNavigate();
  
    useEffect(() => {
      const images = [rocks, mountains, flowers, sun, oregon];
      const randomIndex = Math.floor(Math.random() * images.length);
      setRandomImage(images[randomIndex]);
    }, []);
  
    // This area would handle verification 
    const handleSignIn = (event) => {
      // event.preventDefault();
      console.log("Username:", username);
      console.log("Password:", password);
      alert("Sign-in successful! (Stub message)");
      // Use this line to navigate to the dashboard
      navigate("/dashboard");
    };
  
    return (
      <form onSubmit={handleSignIn}>
      <div className="App">
        <header className="App-header">
        </header>
        <div className="App-body">
        <div className="sign-in-section" style={{ backgroundColor: "#dcf0edff", width: "32%", padding: "180px" ,  marginTop: "-90px" ,  borderRadius: "10px" , position: "relative", textAlign: "center"}}>
        <img src={logo} alt="Therapy Logo" className="logo" style={{ position: "absolute", marginBottom: "340px", width: "150px" }} />
        <h2 style={{ marginTop: "0" }}>Sign in using your account credentials</h2>
            <form className="sign-in-form" onSubmit={handleSignIn}> {/* // handle sign in */}
              <div className="form-group" style={{ marginBottom: "20px" }}>
                <label htmlFor="username">Username:</label>
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  required
                />
              </div>
              <div className="form-group" style={{ marginBottom: "10px" }}>
                <label htmlFor="password">Password:</label>
                <input
                  type="password"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                />
              </div>
              <button type="submit" className="sign-in-button">
                Sign In
              </button>
            </form>
          </div>
          <div className="image-section" style={{ width: "50%", backgroundColor: "white" }}>
            {randomImage && <img src={randomImage} alt="Random Display" className="display-image" />} {/* // && = AND  */}
          </div>
          <div className="bottom-bar" style={{ backgroundColor: "#269581ff", color: "white", padding: "60px 10px", position: "absolute", bottom: "0", width: "94%", display: "flex", justifyContent: "flex-end" }}>
          <span>TheraText Solutions. Kearney, NE. 
          TheraText Solutions. <br /> Kearney, NE. <br /> 
          theratext.solutions@gmail.com.</span>
        </div>
        </div>
      </div>
      </form>
    );
  }
  export default SignIn;