Not getting the App to route to sign in and dashboard
