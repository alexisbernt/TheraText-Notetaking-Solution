// import React, { useState, useEffect } from "react";

import dashboardIcon1 from "./icon1.png";
import dashboardIcon2 from "./icon2.png";
import dashboardIcon3 from "./icon3.png";
import dashboardIcon4 from "./icon4.png";

// Needs edits still

function Dashboard() {
    const icons = [
      { src: dashboardIcon1, alt: "Icon 1" },
      { src: dashboardIcon2, alt: "Icon 2" },
      { src: dashboardIcon3, alt: "Icon 3" },
      { src: dashboardIcon4, alt: "Icon 4" }
    ];
  
    return (
      <div className="dashboard" style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", backgroundColor: "#f5f5f5" }}>
        <div className="circle-container" style={{ position: "relative", width: "300px", height: "300px" }}>
          {icons.map((icon, index) => {
            const angle = (index / icons.length) * 2 * Math.PI;
            const x = Math.cos(angle) * 120 + 140;
            const y = Math.sin(angle) * 120 + 140;
            return (
              <img
                key={index}
                src={icon.src}
                alt={icon.alt}
                style={{
                  position: "absolute",
                  top: `${y}px`,
                  left: `${x}px`,
                  width: "50px",
                  height: "50px",
                  cursor: "pointer"
                }}
                onClick={() => alert(`${icon.alt} clicked!`)}
              />
            );
          })}
        </div>
      </div>
    );
  }

export default Dashboard;
  