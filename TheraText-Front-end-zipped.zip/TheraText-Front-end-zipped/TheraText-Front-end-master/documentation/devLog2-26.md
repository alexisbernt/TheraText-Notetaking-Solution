# Week of 2/24/25 - 3/3/25

Alexis: On 2/26. Reupdated all the src files. 
We now have various routes set up that are able to be navigated to:
- Main: <Route path="/" element={<SignIn />} /> Default route displays SignIn
- <Route path="/dashboard" element={<Dashboard />} />
- <Route path="/survey" element={<StarterScreen />} />
- <Route path="/select" element={<ImageSelectionGame />} />
- <Route path="/sleep" element={<SleepTracker />} />
