# Development Done on March 5th 2025

Here are the routes that are now avaliable:
<Route path="/" element={<SignIn />} /> Default route displays SignIn 
           <Route path="/dashboard" element={<Dashboard />} />
           <Route path="/survey" element={<StarterScreen />} />
           <Route path="/select" element={<ImageSelectionGame />} />
           <Route path="/sleep" element={<SleepTracker />} />
           <Route path="/social" element={<SocialTracker />} />
           <Route path="/pessimistic" element={<Puffin/>} />
           <Route path="/smiley" element={<Smiley />} />
           <Route path="/presessionquestion" element={<PreSessionQuestion />} />
         </Routes>
