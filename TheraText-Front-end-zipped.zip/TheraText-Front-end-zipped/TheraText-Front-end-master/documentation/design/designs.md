# Designs 

### 8/17/2025 - TheraText UI Design Overarching Implementation
