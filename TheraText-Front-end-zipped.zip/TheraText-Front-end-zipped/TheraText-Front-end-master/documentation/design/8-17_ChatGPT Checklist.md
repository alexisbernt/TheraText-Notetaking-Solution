📋 UI/UX Retention Checklist
🎨 Visual & Aesthetic

 Consistent typography, colors, and icon styles

 Sufficient color contrast for accessibility

 Visual hierarchy (important actions stand out)

 Clean layouts with breathing room (whitespace)

 Brand personality visible in UI (not generic)

🧭 Navigation & Flow

 Easy to understand navigation (no guessing)

 Clear “home” or “main hub” for orientation

 Progressive disclosure (show complexity gradually)

 Breadcrumbs or tabs for multi-step tasks

 Back/undo option always available

⚡ Performance & Responsiveness

 App loads in <3 seconds

 Animations are smooth & purposeful (not distracting)

 Works across devices & screen sizes (responsive/mobile-first)

 Buttons & touch targets sized properly for fingers

 Fast feedback for user actions (loading states, progress bars)

🧑‍💻 User-Centered Features

 Personalized touches (user’s name, preferences remembered)

 Onboarding highlights core value in <60 seconds

 Empty states guide user with next steps (not blank screens)

 Search + filter tools available if content is large

 Error messages written in human language, not tech jargon

🎮 Engagement & Motivation

 Streak counters, achievements, or progress indicators

 Gentle gamification (badges, milestones, levels if relevant)

 Subtle encouragement (“You’re on a 3-day streak!”)

 Notifications are opt-in and meaningful (not spammy)

 Opportunities for social proof (sharing, leaderboards, feedback)

🤝 Trust & Comfort

 Privacy policy & permissions explained clearly

 Data use transparency (why info is needed)

 Confirmation before destructive actions (delete, reset)

 Offline-friendly or error-resilient (don’t just crash)

 Help/support easy to find (chat, FAQ, docs)

✅ Tip: Run through this checklist after each design iteration to spot weak points. You can also score each category from 1–5 to see which areas need the most work.
