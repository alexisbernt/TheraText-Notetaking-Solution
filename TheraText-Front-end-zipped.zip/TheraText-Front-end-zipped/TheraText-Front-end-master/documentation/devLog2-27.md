Connected a nav bar that goes to some of the routes - you can get to the nav bar on the "localhostport# + /sleep" screen.


Here is a picture of the Dashboard or web type of landing page I am thinking of (simple mock-up):
![Uploading image.png…]()
