# Development Log for 3/29/2025

This week I prepared the front-end and took care of the styling so now everything is in a consistent sized box for the survey. I also added a component to meaure pessimism and optimism. This is the Green, Yellow, Red light component.

Within the starter-screen.js there is The question-box with consistent width and height.

Then I went in to some of the respective components and adjusted the images, headings, and positionings so they would fit on the question-box.
