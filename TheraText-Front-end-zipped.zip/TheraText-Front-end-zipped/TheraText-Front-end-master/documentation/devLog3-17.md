Wouter: https://www.dhiwise.com/blog/design-converter/wouter-easy-routing-for-react-and-preact-developers

FramerMotion: https://www.geeksforgeeks.org/framer-motion-introduction-and-installation/

Now when you navigate to './dashboard' you get a simple landing page. Design still needs to be added in. 
