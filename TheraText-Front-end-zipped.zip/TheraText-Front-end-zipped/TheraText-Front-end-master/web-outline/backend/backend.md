How making calls between front-end and back-end using React.
