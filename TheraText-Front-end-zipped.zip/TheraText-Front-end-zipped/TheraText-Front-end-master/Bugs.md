# A list of bugs and features needing fixed/added
* 401 alert
  * When signing in with a user that doesn't exist, you get  401 alert.
  * This should be replaced with a nice react thing letting user know username or password was incorrect.
* 